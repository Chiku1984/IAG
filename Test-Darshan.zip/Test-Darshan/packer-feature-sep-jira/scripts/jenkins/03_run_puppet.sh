#!/usr/bin/env bash

# Set external facts
sudo -E sh -c "mkdir -p /etc/facter/facts.d"
sudo -E sh -c "echo '---' > /etc/facter/facts.d/role_stage.yaml"
sudo -E sh -c "echo 'role: ${ROLE}' >> /etc/facter/facts.d/role_stage.yaml"
sudo -E sh -c "echo 'stage: ${STAGE}' >> /etc/facter/facts.d/role_stage.yaml"

# pass puppet debug
if [ "$DEBUG" == true ]; then
  debug=--debug
fi

# Apply Puppet configuration. We need to tell the rvmsudo command to return the exit code of puppet apply via exit PIPESTATUS, otherwise we get tee's exit code!
rvmsudo -E sh -c "cd /opt/puppet; puppet apply $debug --detailed-exitcodes --ordering=manifest --hiera_config=hiera.yaml --modulepath=modules manifests/site.pp 2>&1 | tee /root/${ROLE}_${STAGE}.log; exit \${PIPESTATUS[0]}"

# Via Puppet's --detailed-exitcodes we expect exit code 2, which means: "The run succeeded, and some resources were changed." Anything else is considered failure.
rc=$?
echo "Puppet apply exited with exit code $rc."
if [ $rc -eq 2 ]; then
  exit 0
else
  exit 1
fi
