#!/usr/bin/env bash
set -x

# testing only - move to puppet
cat > /etc/yum.repos.d/treasuredata.repo << EOF
[treasuredata]
name=TreasureData
baseurl=http://packages.treasuredata.com/2/redhat/\$releasever/\$basearch
enabled=true
gpgcheck=true
gpgkey=https://packages.treasuredata.com/GPG-KEY-td-agent
EOF

chmod 0644 /etc/yum.repos.d/treasuredata.repo

yum install epel-release -y

#Putting PSQL repo to install latest postgresql client on OS and istall postgresql12 package.
#yum install -y https://download.postgresql.org/pub/repos/yum/reporpms/EL-7-x86_64/pgdg-redhat-repo-latest.noarch.rpm
#yum install postgresql12

wget -O- -q $(awk -F= '/^gpgkey=/ {print $2}' /etc/yum.repos.d/treasuredata.repo) > treasuredata.gpgkey
rpm --import treasuredata.gpgkey
rm -f treasuredata.gpgkey

yum install -y td-agent jq

# hard code gluster to 3.8 until we fix ssl issue with 3.12 client
yum install -y glusterfs-fuse-3.8.4-54.15.el7.x86_64 glusterfs-client-xlators-3.8.4-54.15.el7.x86_64 glusterfs-3.8.4-54.15.el7.x86_64 glusterfs-libs-3.8.4-54.15.el7.x86_64
# is nmap-ncat a security hole ? -e option is available - anyway i've monkey patched Specinfra::Command::Redhat::V7::Host
# nmap-ncat

# Some ugly caching until I can fix the Puppet Bake issue
# Removing to migrate on Open JDK.
#aws s3 cp s3://${S3_BUCKET}/bake/confluence/jdk-8u181-linux-x64.rpm /tmp/jdk-8u181-linux-x64.rpm
#/usr/bin/rpm -i /tmp/jdk-8u181-linux-x64.rpm
#rm -rf /tmp/jdk-8u181-linux-x64.rpm

# Cache Atlassian artifacts
/usr/local/bin/aws s3 cp s3://${S3_BUCKET}/bake/confluence/atlassian-confluence-7.13.1.tar.gz /home/ec2-user/atlassian-confluence-7.13.1.tar.gz
#/usr/local/bin/aws s3 cp s3://${S3_BUCKET}/bake/confluence/atlassian-jira-software-8.5.6.tar.gz /home/ec2-user/atlassian-jira-software-8.5.6.tar.gz

# Confuence requires the build version in the generated xml
CONF_VERSION=$(ls /home/ec2-user/atlassian-confluence-7.13.1.tar.gz | sed 's~^.*-\([0-9]\+\.[0-9]\+\.[0-9]\+\)\..*$~\1~')
# CONF_BUILD=$(curl -sk -X GET 'https://marketplace.atlassian.com/rest/2/applications/confluence/versions?afterBuildNumber=0&limit=50' | jq "._embedded.versions|map(select(.version==\"${CONF_VERSION}\"))|.[0].buildNumber")
# CONF_BUILD=$(curl -sk -X GET 'https://marketplace.atlassian.com/rest/2/applications/confluence/versions?afterBuildNumber=0&limit=50' | jq "._embedded.versions[] | select(.version==\"${CONF_VERSION}\") | .buildNumber")
CONF_BUILD=8401

cat << EOF > /etc/facter/facts.d/confluence.yaml
---
confluence_build_number: ${CONF_BUILD}
confluence_version: ${CONF_VERSION}
EOF

# Cache DynaTrace Installers for Non-Prod and Prod
wget -O /root/Dynatrace-OneAgent-Linux-UAT.sh https://rqy29932.live.dynatrace.com/installer/oneagent/unix/latest/1TmlhMxZTakFl9FK
wget -O /root/Dynatrace-OneAgent-Linux-PRD.sh https://fdm19711.live.dynatrace.com/installer/oneagent/unix/latest/hAH3H2PoUVq7UiPE
chmod +x /root/Dynatrace-OneAgent-Linux-PRD.sh /root/Dynatrace-OneAgent-Linux-UAT.sh

# task runner - should be in Puppet
mkdir /opt/taskrunner
wget -O /opt/taskrunner/rds-combined-ca-bundle.pem https://s3.amazonaws.com/rds-downloads/rds-combined-ca-bundle.pem
/usr/local/bin/aws s3 cp s3://${S3_BUCKET}/bake/taskrunner/TaskRunner-1.0.jar /opt/taskrunner/TaskRunner-1.0.jar
/usr/local/bin/aws s3 cp s3://${S3_BUCKET}/bake/taskrunner/mysql-connector-java-bin.jar /opt/taskrunner/mysql-connector-java-bin.jar
chmod 600 /opt/taskrunner/rds-combined-ca-bundle.pem
chown -R taskrunner:taskrunner /opt/taskrunner

#Putting PSQL repo to install latest postgresql client on OS and istall postgresql10 package.
yum install -y https://download.postgresql.org/pub/repos/yum/reporpms/EL-7-x86_64/pgdg-redhat-repo-latest.noarch.rpm
yum install postgresql10

# PostgreSQL binaries - required for connecting to 9.6
# yum install -y http://download.postgresql.org/pub/repos/yum/9.6/redhat/rhel-7-x86_64/pgdg-redhat96-9.6-3.noarch.rpm
# yum install -y postgresql96 -y

# python modules required for hack to generate a DNS cache in the local hosts file
pip install --upgrade dnspython netifaces netaddr certifi

# upgrade specinfra to support Puppet Facter & remove old version
gem install specinfra:2.73.3
gem cleanup specinfra

# install serverspec-aws - https://github.com/SaltwaterC/serverspec-aws
# rolled a gem from commit 79e50e37 in master branch, which has more features (e.g. encrypted ami)
/usr/local/bin/aws s3 cp s3://${S3_BUCKET}/bake/confluence/serverspec-aws-79e50e37.gem /tmp/serverspec-aws-79e50e37.gem
gem install /tmp/serverspec-aws-79e50e37.gem
rm -rf /tmp/serverspec-aws-79e50e37.gem

# addition packages and configuration for diaplaying Powerpoint documents in Confluence
yum install -y curl cabextract xorg-x11-font-utils fontconfig
rpm -i https://downloads.sourceforge.net/project/mscorefonts2/rpms/msttcore-fonts-installer-2.6-1.noarch.rpm

# install EFS client
/usr/local/bin/aws s3 cp s3://${S3_BUCKET}/bake/confluence/amazon-efs-utils-1.4-1.el7.noarch.rpm /tmp/amazon-efs-utils-1.4-1.el7.noarch.rpm
yum install -y /tmp/amazon-efs-utils-1.4-1.el7.noarch.rpm
rm -f /tmp/amazon-efs-utils-1.4-1.el7.noarch.rpm
sed -i -E 's~^((stunnel_check_cert_hostname|stunnel_check_cert_validity) = )(true|false)$~\1 false~g' /etc/amazon/efs/efs-utils.conf

# After migrating to openJdk, app does not connect to RDS, downloading the rds pem file, passing it as "static" to server.xml
cd /etc/ssl
wget https://s3.amazonaws.com/rds-downloads/rds-combined-ca-bundle.pem
chmod 644 rds-combined-ca-bundle.pem

# Chaning process limit for JIRA as recommended by Atlassian, we are making it unlimited, also setting for nofile limit of JIRA.
echo "jira       soft    nproc     unlimited" >> /etc/security/limits.d/20-nproc.conf
echo "jira       soft    nofile    16384" >> /etc/security/limits.conf
echo "jira       hard    nofile    32768" >> /etc/security/limits.conf
echo "session    required     pam_limits.so" >> /etc/pam.d/login 