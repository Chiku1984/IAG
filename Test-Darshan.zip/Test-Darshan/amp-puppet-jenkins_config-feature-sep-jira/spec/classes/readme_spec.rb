require 'spec_helper'

describe 'formatting in markdown' do
  ['README.md', Dir.glob('docs/jobs/*.md')].flatten.each do |f|
    context f do
      before(:each) do
        begin
          @content = File.read(f)
        rescue Errno::ENOENT
          puts "#{f} file not found"
        end
      end

      if f == 'README.md'
        it 'README.md should actually exist' do
          expect { File.read(f) }.to_not raise_error(Errno::ENOENT)
        end
      end

      it 'should have a space after the hash in heading markers' do
        if @content =~ /^#+[^# ]/
          puts "Hint run: perl -pi -e 's/^(#+)([^# ])/$1 $2/' #{f} to fix this"
        end
        expect(@content).to_not match /^#+[^# ]/
      end

      it 'should contain Kramdown compatible code block markers (not backticks)' do
        if @content =~ /^```/
          puts "Hint run: perl -pi -e 's/^```/~~~/' #{f} to fix this"
        end
        expect(@content).to_not match /^```/
      end

      it 'should contain Kramdown compatible code block markers (a space after ~~~)' do
        if @content =~ /^~~~[a-z]/
          puts "Hint run: perl -pi -e 's/^~~~([a-z])/~~~ $1/' #{f} to fix this"
        end
        expect(@content).to_not match /^~~~[a-z]/
      end
    end
  end
end
