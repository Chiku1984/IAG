# THIS FILE IS CENTRALLY MANAGED BY update_rspec.rb!
# DO NOT EDIT IT HERE!

require 'puppetlabs_spec_helper/module_spec_helper'
require 'rspec-puppet-utils'

def verify_contents(subject, title, expected_lines)
  content = subject.resource('file', title).send(:parameters)[:content].gsub(/\r/, '')
  expect(content.split("\n") & expected_lines).to match_array expected_lines.uniq
end

RSpec.configure do |c|
  c.formatter    = :documentation
  c.tty          = true
  c.hiera_config = './hiera.yaml'
  c.mock_framework = :rspec
  c.default_facts = {
    :osfamily               => 'RedHat',
    :operatingsystem        => 'RedHat',
    :operatingsystemrelease => '6.8',
    :operatingsystemmajrelease => '6',
    :kernel             => 'Linux',
    :architecture       => 'x86_64',
    :virtualenv_version => '1.7',
    :fqdn               => 'myhost.example.com',
    :concat_basedir     => '/var/lib/puppet/concat',
    :ipaddress          => '1.1.1.1',
  }
end
