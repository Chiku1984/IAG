require 'timeout'
require 'faraday'
require 'json'

module Serverspec::Type::AMP

  # Perform an HTTP GET request against the serverspec target
  # using {http://www.rubydoc.info/gems/faraday/ Faraday}.
  class Http_Get < Base
    # Http status codes that are tested against for redirect test
    @@redirect_codes = [301, 302, 307, 308]

    def initialize(url, timeout_sec=10, bypass_ssl_verify=false)
      super(url)

      @url = url
      @timed_out_status = false
      @content_str = nil
      @headers_hash = nil
      @response_code_int = nil
      @response_json = nil
      @bypass_ssl_verify = bypass_ssl_verify
      @redirects = false
      @redirect_path = nil
      begin
        Timeout::timeout(timeout_sec) do
          getpage
        end
      rescue Timeout::Error
        @timed_out_status = true
      end
    end

    def getpage
      uri = URI.parse(@url)
      options = []
      options << { ssl: { verify: false } } if @bypass_ssl_verify
      conn = Faraday.new(@url, *options)
      version = ServerspecAMPTypes::VERSION
      conn.headers[:user_agent] = "Serverspec::Type::Http_Get/#{version}"
      conn.headers[:Host] = uri.host
      response = conn.get(@path)
      @response_code_int = response.status
      @content_str = response.body
      @headers_hash = Hash.new('')
      response.headers.each do |header, val|
        @headers_hash[header] = val
      end
      @redirects = @@redirect_codes.include? @response_code_int
      @redirect_path = @redirects ? @headers_hash['location'] : nil
      # try to JSON decode
      begin
        @response_json = JSON.parse(@content_str)
      rescue
        @response_json = {}
      end
    end

    def timed_out?
      @timed_out_status
    end

    def headers
      @headers_hash
    end

    def json
      @response_json
    end

    def status
      if @timed_out_status
        0
      else
        @response_code_int
      end
    end

    def body
      @content_str
    end

    def redirected_to? (redirect_path)
      @redirects and @redirect_path == redirect_path
    end

    def redirected?
      @redirects
    end

    private :getpage
  end

  def http_get(url, timeout_sec=10, bypass_ssl_verify=false)
    Http_Get.new(url, timeout_sec, bypass_ssl_verify)
  end

end

include Serverspec::Type::AMP
