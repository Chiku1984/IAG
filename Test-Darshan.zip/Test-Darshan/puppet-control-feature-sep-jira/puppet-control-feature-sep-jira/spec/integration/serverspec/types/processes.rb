module Serverspec::Type::AMP

  class Processes < Base

    def initialize(name, match)
       super(name)
       all_processes = @runner.run_command('ps --no-headers -Ao pid,cmd').stdout.lines.map(&:chomp)
       @pids = all_processes.map do |line|
         mdata = /^\s*(?<pid>\d+)\s(?<cmd>.*)$/.match(line)
         h = Hash[ mdata.names.map(&:to_sym).zip( mdata.captures ) ]
      end
      @pids = @pids.select { |h| h[:cmd] =~ match }
    end

    def count?(count)
      @pids.size == count
    end

    def group?(group)
      get_column('egroup').all? { |c| c == group }
    end

    def user?(user)
      get_column('euser').all? { |c| c == user }
    end

    def running?
      count > 0
    end

    def args
      get_column('args')
    end

    #
    #
    #
    def count
      @pids.size
    end

    def user
      get_column('euser').uniq.join(',')
    end

    def group
      get_column('egroup').uniq.join(',')
    end

    private

    def get_column(col)
      @runner.run_command("ps --no-headers -p #{@pids.map(&extract(:pid)).join(' ')} -o #{col}").stdout.lines.map(&:chomp)
    end

    def extract(k)
      ->(h) { h[k] }
    end

  end

  def processes(name, match)
    Processes.new(name, match)
  end

end

include Serverspec::Type::AMP
