#
# Common tests for Teamtools application
#

shared_examples 'teamtools application' do |application:,
                                            user:,
                                            group:,
                                            service:,
                                            process_arg:,
                                            listening:,
                                            loadbalancer_ports:,
                                            db_host:,
                                            cluster_security_group:,
                                            hosted_domain:,
                                            external_domainname:,
                                            jvm_min_size:,
                                            jvm_max_size:,
                                            jvm_opts: []|

  mica_ca_subject = /#{Regexp.escape('/C=AU/O=AMP - Internal Services/OU=Infosec/CN=MICA Infosec Issuing CA - ')}(Prod|NonProd)$/
  aws_region = host_inventory['ec2']['placement']['availability-zone'][0...-1]

  describe package('jdk1.8.0_144-1.8.0_144-fcs') do
    it { should be_installed }
  end

  describe group(user) do
    it { is_expected.to exist }
  end

  describe user(user) do
    it { is_expected.to exist }
    it { should belong_to_primary_group user }
    its(:encrypted_password) { should match(/^.{0,2}$/) } # no password
    it { should have_login_shell '/bin/true' }
  end

  describe file('/etc/cron.d/generate_hosts_file') do
    it { should be_file }
    it { should be_mode 644 }
    it { should be_owned_by 'root' }
    it { should be_grouped_into 'root' }
    its(:content) { should match /^\* \* \* \* \* root \/opt\/aws\/generate_hosts_file\.py --vpc 22 --dns/ }
  end

  describe file('/etc/hosts') do
    it { should be_file }
    it { should be_mode 664 }
    it { should be_owned_by 'root' }
    it { should be_grouped_into 'root' }
    its(:content) { should match /^127.0.0.1\s+localhost\s+localhost\.localdomain$/ }
    its(:content) { should match /^\d{1,3}(\.\d{1,3}){3}\s+#{Regexp.escape(external_domainname)}$/ }
    its(:content) { should match /^\d{1,3}(\.\d{1,3}){3}\s+app\.#{Regexp.escape(hosted_domain)}$/ }
    its(:content) { should match /^\d{1,3}(\.\d{1,3}){3}\s+app\.#{Regexp.escape(hosted_domain.gsub(/confluence/i, 'jira'))}$/ }
    its(:content) { should match /^\d{1,3}(\.\d{1,3}){3}\s+ip\-\d{1,3}(\-\d{1,3}){3}\s+ip\-\d{1,3}(\-\d{1,3}){3}\.#{Regexp.escape(aws_region)}\.compute\.internal$/ }
  end

  describe file('/shared') do
    it { should be_mounted.with(:type => 'fuse.glusterfs') }
  end

  describe file("/shared/#{application}") do
    it { should be_directory }
    it { should be_owned_by user }
    it { should be_grouped_into group }
  end

  describe service(service) do
    it { should be_enabled }
    it { should be_running }
  end

  describe processes(application, /^\/usr\/java\/default\/bin\/java\s.*\s#{Regexp.escape(process_arg)}\s/) do
    it { should be_user user }
    it { should be_group group }
    it { should be_count 1 }
    # its(:args) { should include "-Xms#{jvm_min_size}m" }
    # its(:args) { should include "-Xmx#{jvm_max_size}m" }
    its(:args) { is_expected.to all( include " -Xms#{jvm_min_size}m " ) }
    its(:args) { is_expected.to all( include " -Xmx#{jvm_max_size}m " ) }
    its(:args) { is_expected.to all( include " -Dhttp.proxyHost=c2proxy.ampaws.com.au " ) }
    its(:args) { is_expected.to all( include " -Dhttp.proxyPort=8080 " ) }
    its(:args) { is_expected.to all( include " -Dhttps.proxyHost=c2proxy.ampaws.com.au " ) }
    its(:args) { is_expected.to all( include " -Dhttps.proxyPort=8080 " ) }
    its(:args) { is_expected.to all( include " -Dhttp.nonProxyHosts=localhost|169.254.169.254|192.168.*.*|10.*.*.*|" ) }
    jvm_opts.each do |java_opt|
      its(:args) { is_expected.to all( include " #{java_opt}" ) }
    end
    # |*.confluence-np.ampaws.com.au|*.jira-np.ampaws.com.au
    it { is_expected.to be_running }
  end

  context "listening ports" do
    listening.map { |a| a.split(':', 2) }.each do |address, port|
      describe port(port) do
        it { should be_listening.on(address).with('tcp') }
      end
    end
  end

  context "can connect the load balancer ports" do
    describe host("teamtools.#{hosted_domain}") do
      loadbalancer_ports.each do |port|
        context "on port #{port}" do
          it { should be_reachable.with( :port => port, :proto => 'tcp', :timeout => 1 ) }
        end
      end
    end
  end

  context "load balancer certificates" do

    certificates = [
      "app.#{hosted_domain}",
      "app.#{hosted_domain.gsub(/confluence/i, 'jira')}",
      external_domainname,
    ]

    # parent_subject = '/C=AU/O=AMP Internal Services - projects/OU=Cost_Centre:TW033/CN='

    certificates.each do |certificate|
      describe loadbalancer_certificate("app.#{hosted_domain}", 443, certificate) do
        it { should be_certificate }
        it { should be_valid }
        its(:issuer) { should match mica_ca_subject }
        its(:subject) { should match /\/CN=#{Regexp.escape(certificate)}(\/.*)?/ }
        its(:validity_in_days) { should be >= 30 }
      end
    end

  end

  context "can connect to the database" do
    describe host(db_host) do
      it { should be_reachable.with( :port => 5432, :proto => 'tcp', :timeout => 1 ) }
    end
  end

  describe file('/opt/taskrunner/taskrunner.sh') do
    its(:content) { should match /^\s+\-\-workerGroup #{application}-backup-schedule\s+\\$/ }
  end

  #
  # Additional packages
  #
  context "system packages" do

    yum_pkgs = [ 'postgresql96', 'jq', 'curl', 'cabextract', 'xorg-x11-font-utils', 'fontconfig', 'msttcore-fonts-installer' ] #, 'nmap-ncat' ]
    yum_pkgs.each do |pkg|
      describe package(pkg) do
        it { should be_installed }
      end
    end

    pip_pkgs = [ 'requests', 'dnspython', 'netifaces', 'netaddr', 'certifi']
    pip_pkgs.each do |pkg|
      describe package(pkg) do
        it { should be_installed.by('pip') }
      end
    end

  end

  # Prod/Non-Prod should have a terminal lifecycle hook
  if host_inventory['facter']['aws_account'] !~ /\-pilot$/

    describe autoscaling_lifecycle_hooks do
      its (:hooks) {
        is_expected.to include_hash_matching(
            :heartbeat_timeout => 7200,
            :lifecycle_transition => 'autoscaling:EC2_INSTANCE_TERMINATING'
        )
      }
    end
  end

end
