require_relative './autoscaling/lifecyclehooks.rb'

module Serverspec::Type

  include Serverspec::Type::AWS

  def autoscaling_lifecycle_hooks(group_name = nil, instance = nil)

     unless group_name
       aws = instance.nil? ? Aws::EC2::Client.new : instance
       group_name = aws.describe_instances(
         instance_ids: [host_inventory['ec2']['instance-id']]
       ).reservations[0].instances[0].tags.find {|x| x.key =='aws:autoscaling:groupName' }.value
     end

     AWS::AutoScaling::LifecycleHooks.new(group_name, instance)
  end

end

include Serverspec::Type
