require 'serverspec-aws'
require 'aws-sdk'


module Serverspec::Type

  # Monkey patch Serverspec::Type::AWS::EC2::SecurityGroup
  # - add check for port and cidr source
  module AWS::EC2
    class SecurityGroup

      def port_accessible_from?(cidr_s, port)
        return false if ingress_permissions.empty?

        cidr = NetAddr::CIDR.create(cidr_s)
        ingress_permissions.map { |ingress|
          # also match the AWS Any port rule
          ingress.from_port ||= 0
          ingress.to_port ||= 65536
          if (ingress.from_port..ingress.to_port) === port
          # if ingress.from_port <= port <= ingress.to_port
            ingress.ip_ranges.flatten.map(&:cidr_ip).map do |source_cidr|
              cidr_s == source_cidr || cidr.is_contained?(source_cidr)
            end
          else
            false
          end
        }.flatten.include? true
      end

    end


    class SecurityGroups < Base
      def initialize(sg_ids, instance = nil)
        super(sg_ids.join(','))
        @sg_ids = sg_ids
        if @sg_ids.empty?
          raise "Missing #{item_name} with the specified name were returned"
        end
        @aws = instance.nil? ? Aws::EC2::Client.new : instance
        get_security_groups sg_ids
      end

      def accessible_from?(cidr_s)
        return false if ingress_permissions.empty?

        cidr_s = validate_cidr(cidr_s)

        cidr = NetAddr::CIDR.create(cidr_s)
        allowed_cidrs = ingress_permissions.map(&:ip_ranges)
                                           .flatten.map(&:cidr_ip)
        matching_rules = allowed_cidrs.map do |source_cidr|
          cidr_s == source_cidr || cidr.is_contained?(source_cidr)
        end
        matching_rules.include? true
      end


      def port_accessible_from?(cidr_s, port)
        # what about access from other security groups
        return false if ingress_permissions.empty?

        cidr_s = validate_cidr(cidr_s)
        if port !~ /\A(?:(?<proto>udp|tcp):)?(?<port>\d+)\Z/
          raise "port_accessible_from: port must be in the format 111 or udp:111 or tcp:22"
        end
        ip_proto = $LAST_MATCH_INFO[:proto] || -1
        port_no = $LAST_MATCH_INFO[:port]

        cidr = NetAddr::CIDR.create(cidr_s)
        matching_rules = ingress_permissions.map do |ingress|
          # also match the AWS Any port rule
          ingress.from_port ||= 0
          ingress.to_port ||= 65536
          if (ingress.from_port.to_i..ingress.to_port.to_i) === port_no.to_i and (['-1', ip_proto].uniq.include? ingress.ip_protocol)
            ingress.ip_ranges.flatten.map(&:cidr_ip).map do |source_cidr|
              cidr_s == source_cidr || cidr.is_contained?(source_cidr)
            end
          else
            false
          end
        end
        matching_rules.flatten.include? true
      end

      private

      # allow for host and not just a CIDR, so append /32
      def validate_cidr(cidr_s)
        case cidr_s
        when Resolv::IPv4::Regex
          "#{cidr_s}/32"
        when Regexp.union(/\A/, Resolv::IPv4::Regex, /\/([1-2]?[0-9]|3[0-2])\Z/)
          cidr_s
        else
          raise "cidr #{cidr_s} must be in the format 192.168.0.1 or 192.168.0.0/24"
        end
      end

      def ingress_permissions
        @sgs.map(&:ip_permissions).flatten
      end

      def get_security_groups(ids)
        sgs = @aws.describe_security_groups(group_ids: ids).security_groups
        if sgs.empty? or (ids.size != sgs.size)
          raise "Miss match on security groups details returned from AWS"
        end
        @sgs = sgs
      end

    end
  end



  include Serverspec::Type::AWS

  def ec2_image(image_id, instance = nil)
     AWS::EC2::Image.new(image_id, instance)
  end

  def ec2_security_group(sg_id, instance = nil)
     AWS::EC2::SecurityGroup.new(sg_id, instance)
  end

  def ec2_security_groups(sg_ids, instance = nil)
     AWS::EC2::SecurityGroups.new(sg_ids, instance)
  end

end

include Serverspec::Type
