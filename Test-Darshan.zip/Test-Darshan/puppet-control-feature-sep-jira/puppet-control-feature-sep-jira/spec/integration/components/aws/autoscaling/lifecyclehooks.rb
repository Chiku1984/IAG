module Serverspec
  module Type
    module AWS
      # The AutoScaling module contains the AutoScaling API resources
      module AutoScaling
        # The Group class exposes the AutoScaling::Group resources
        class LifecycleHooks < Base
          # AWS SDK for Ruby v2 Aws::AutoScaling::Client wrapper for
          # initializing a Group resource
          # @param group_name [String] The name of the Group
          # @param instance [Class] Aws::AutoScaling::Client instance
          # @raise [RuntimeError] if group_name.nil?
          # @raise [RuntimeError] if groups.length == 0
          # @raise [RuntimeError] if groups.length > 1
          def initialize(group_name, instance = nil)
            # check_init_arg 'group_name', 'AutoScaling::Group', group_name
            @group_name = group_name
            @aws = instance.nil? ? Aws::AutoScaling::Client.new : instance
            get_hooks group_name
          end

          # Returns the String representation of AutoScaling::Group
          def to_s
            "AutoScaling Group Lifecycle Hooks: #{@group_name}"
          end

          def hooks
            @hooks.map(&:to_h)
          end

          private

          def get_hook(transition_type)
            @hooks.to_h.find {|x| x.lifecycle_transition == transition_type }
          end

          # @private
          def get_hooks(name)
            hooks = @aws.describe_lifecycle_hooks(
              auto_scaling_group_name: name
            ).lifecycle_hooks
            @hooks = hooks
          end
        end
      end
    end
  end
end
