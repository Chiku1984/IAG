require_relative '../serverspec/types'

#
# TD agent Tests
#
shared_examples 'td-agent agent' do

  describe group('td-agent') do
    it { is_expected.to exist }
  end

  describe user('td-agent') do
    it { is_expected.to exist }
    it { should belong_to_primary_group 'td-agent' }
    its(:encrypted_password) { should match(/^.{0,2}$/) } # no password
    it { should have_login_shell '/sbin/nologin' }
  end

  describe package('td-agent') do
    it { should be_installed }
  end

  describe service('td-agent') do
    it { should be_enabled }
    it { should be_running }
  end

  describe processes('td-agent', /^#{Regexp.escape('/opt/td-agent/embedded/bin/ruby /usr/sbin/td-agent')}/) do
    it { should be_user 'td-agent' }
    it { should be_group 'td-agent' }
    its(:count) { should >= 1 }
    it { is_expected.to be_running }
  end

end
