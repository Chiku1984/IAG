require_relative '../serverspec/types'
require_relative './aws'

#
# Taskrunner Tests
#
shared_examples 'taskrunner agent' do

  aws_region = host_inventory['ec2']['placement']['availability-zone'][0...-1]

  # describe package('java-1.7.0-openjdk') do
  #   it { should be_installed }
  # end

  # why is this not part of a package?
  describe file('/usr/lib/jvm/java-1.7.0-openjdk/bin/java') do
    it { should be_file }
    it { should be_mode 755 }
    it { should be_owned_by 'root' }
    it { should be_grouped_into 'root' }
  end

  describe group('taskrunner') do
    it { is_expected.to exist }
  end

  describe user('taskrunner') do
    it { is_expected.to exist }
    it { should belong_to_primary_group 'taskrunner' }
    its(:encrypted_password) { should match(/^.{0,2}$/) } # no password
  end

  describe file('/opt/taskrunner/rds-combined-ca-bundle.pem') do
    it { should be_file }
    it { should be_mode 600 }
    it { should be_owned_by 'root' }
    it { should be_grouped_into 'root' }
  end

  describe file('/opt/taskrunner/TaskRunner-1.0.jar') do
    it { should be_file }
    it { should be_mode 644 }
    it { should be_owned_by 'taskrunner' }
    it { should be_grouped_into 'taskrunner' }
  end

  describe file('/opt/taskrunner/taskrunner.sh') do
    it { should be_file }
    it { should be_mode 755 }
    it { should be_owned_by 'taskrunner' }
    it { should be_grouped_into 'taskrunner' }
    its(:content) { should match /^export JAVA_HOME=\/usr\/lib\/jvm\/java-1\.7\.0-openjdk$/ }
    its(:content) { should match /^\s+\-\-endpoint\s+datapipeline\.#{Regexp.escape(aws_region)}\.amazonaws\.com\s+\\$/ }
    its(:content) { should match /^\s+\-\-region\s+#{Regexp.escape(aws_region)}\s+\\$/ }
    its(:content) { should match /^\s+\-\-proxyHost\s+c2proxy\.ampaws\.com\.au\s+\\$/ }
    its(:content) { should match /^\s+\-\-proxyPort\s+8080$/ }
    its(:content) { should match /^\s+\-\-logUri\s+s3:\/\/amp[a-z\-]+\/data-pipeline\/logs\s+\\$/ }
  end

  describe cron do
    it { should have_entry('*/10 * * * * /bin/bash /opt/taskrunner/taskrunner.sh > /dev/null 2>&1').with_user('taskrunner') }
  end

  describe processes('taskrunner', /^java -jar TaskRunner-1.0.jar/) do
   it { should be_user 'taskrunner' }
   it { should be_group 'taskrunner' }
   it { should be_count 1 }
   it { is_expected.to be_running }
  end

end
