# THIS FILE IS CENTRALLY MANAGED BY update_rspec.rb!
# DO NOT EDIT IT HERE!

require 'spec_helper'

project = %x{git remote -v}.split[1].gsub(/^git.*:/, '').gsub(/\/.*$/, '')

packer_git_url = ENV['PACKER_GIT_URL'] ? ENV['PACKER_GIT_URL'] : "git@gitlab.ccoe.ampaws.com.au:#{project}/packer.git"
packer_git_ref = ENV['PACKER_GIT_REF'] ? ENV['PACKER_GIT_REF'] : 'master'
packer_dir     = "#{project}_packer"

ccoe_packer_git_url = ENV['CCOE_PACKER_GIT_URL'] ? ENV['CCOE_PACKER_GIT_URL'] : 'git@gitlab.ccoe.ampaws.com.au:CCOE/packer.git'
ccoe_packer_git_ref = ENV['CCOE_PACKER_GIT_REF'] ? ENV['CCOE_PACKER_GIT_REF'] : 'master'
ccoe_packer_dir     = 'CCOE_packer'

%x{git clone #{ccoe_packer_git_url} -b #{ccoe_packer_git_ref} #{ccoe_packer_dir}}

# For the CCOE code bases only, packer_git_url will normally equal ccoe_packer_git_url.
unless packer_git_url == ccoe_packer_git_url
  %x{git clone #{packer_git_url} -b #{packer_git_ref} #{packer_dir}}
end

describe 'Hiera data consistency for Baking' do
  Dir.glob("hieradata/aws/*.yaml").delete_if{|x| x =~ /auth/}.each do |f|
    hiera = YAML::load_file(f)
    if hiera.has_key?('jenkins_jobs')

      # This says "if the Bake_AMI etc are all in jenkins_jobs".
      if (['Bake_AMI', 'Share_AMI', 'Encrypt_AMI'] - hiera['jenkins_jobs'].keys).empty?

        bake_ami_bake_types    = hiera['jenkins_jobs']['Bake_AMI']['config']['bake_types']
        share_ami_bake_types   = hiera['jenkins_jobs']['Share_AMI']['config']['bake_types']
        encrypt_ami_bake_types = hiera['jenkins_jobs']['Encrypt_AMI']['config']['bake_types']

        if project == 'CCOE'
          context f do
            it 'Bake_AMI keys should match Share_AMI keys' do
              expect(bake_ami_bake_types.keys).to match_array share_ami_bake_types
            end

            it 'Bake_AMI keys should match Encrypt_AMI keys minus Cloud 2 Bakes' do
              expect(bake_ami_bake_types.keys.delete_if{|x| x =~ /Cloud2_/}).to match_array encrypt_ami_bake_types
            end
          end
        end

        context "packer var file and template should exist in file #{f}" do
          bake_ami_bake_types.keys.each do |bake_type|
            it bake_type do

              var_files      = Dir.glob("*packer/variables/#{bake_ami_bake_types[bake_type]['packer_var_file']}")
              template_files = Dir.glob("*packer/templates/#{bake_ami_bake_types[bake_type]['packer_template']}")

              unless var_files.size == 1
                puts "  Found #{var_files}"
              end
              unless template_files.size == 1
                puts "  Found #{template_files}"
              end

              expect(var_files.size).to eq 1
              expect(template_files.size).to eq 1
            end
          end
        end

        context "ami_filters in file #{f}" do
          bake_ami_bake_types.keys.delete_if{|x| x =~ /Cloud2_/}.each do |bake_type|
            it "ami_filter for bake_type #{bake_type} should match cloud2-(?:rhel6|rhel7|win2k12)" do
              expect(bake_ami_bake_types[bake_type]['ami_filter']).to match /Values=cloud2-(?:rhel6|rhel7|win2k12)-/
            end
          end
        end
      end

      if hiera['jenkins_jobs'].has_key?('Share_AMI')
        def get_from_fact(key)
          begin
            %x{grep "'#{key}'" modules/customlib/lib/facter/aws_account.rb}.match(/'(\d+)'/).captures[0]
          rescue
            puts "  failed to find account '#{key}' in customlib"
            ''
          end
        end

        context "Share_AMI cccount_ids block in Hiera file #{f}" do
          hiera['jenkins_jobs']['Share_AMI']['config']['account_ids'].each do |k, v|

            # This is a bit of a hack to avoid solving the problem of handling the
            # structured data in the paas section of the customlib aws_accounts.rb fact.
            next if v =~ /paas/

            it v do
              expect(get_from_fact(v)).to eq k
            end
          end
        end
      end
    end
  end
end
