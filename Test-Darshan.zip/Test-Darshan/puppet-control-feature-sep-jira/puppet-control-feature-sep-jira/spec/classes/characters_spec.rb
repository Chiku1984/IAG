# THIS FILE IS CENTRALLY MANAGED BY update_rspec.rb!
# DO NOT EDIT IT HERE!

require 'spec_helper'

describe 'bad characters in XML file' do
  Dir.glob('modules/{jenkins,jenkins_config}/templates/jobs/*.xml.erb').each do |file|
    it "#{file} should not contain bad characters" do
      content = File.read(file)
      [
        '&quot;',  #  use "
        '&apos;',  #  use '
        '&#13;',   #  line feed - use newline
        '&#xd;',   #  carriage return - use newline
        '\t',      #  tab character - use '  '
      ]
      .each do |bad_character|
        expect(content).to_not match /#{bad_character}/
      end
    end
  end
end
