import org.yaml.snakeyaml.Yaml
import ccoecommon.Common
import ccoecommon.Accounts


def jobName = 'CCOE_Test_Job_A'
def values = new Yaml().load((Accounts.getEnvConfigPath() as File).text)
def config = values['jenkins_jobs'][jobName]['config']

job(jobName) {
    description("This is a test job")
	keepDependencies(false)
	parameters {
        stringParam("Tenant_Git_URL", "${config['tenant_git_url']}", "Tenant Git URL")

        activeChoiceReactiveParam('branch_to_build') {
			description(' Branch to build')
			choiceType('SINGLE_SELECT')
			groovyScript {
				script(Common.gitRef("\$Tenant_Git_URL",config['branch_to_build']))
				fallbackScript('"Script Error"')
			}
			referencedParameter("Tenant_Git_URL")
		}
    }
}
