#!/usr/bin/python

# Copyright: (c) 2019, Robert Lawton <robert.lawton@ba.com>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

ANSIBLE_METADATA = {
    'metadata_version': '1.0',
    'status': ['preview'],
    'supported_by': 'IAG GBS'
}

DOCUMENTATION = '''
---
module: nmcli_facts

short_description: Module for gathering nmcli facts

description:
    - "Uses nmcli to produce NetworkManager configuration facts"

options:

author:
    - Robert Lawton <robert.lawton@ba.com>
'''

EXAMPLES = '''
'''

RETURN = '''
'''

from subprocess import Popen, PIPE
import re

from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils._text import to_text


class Nmcli(object):
    """ This class is a helper to easily perform nmcli commands """

    def __init__(self):
        self.nmcli_facts = {}
        self._connections()
        self._devices()
    
    def _run_nmcli(self,options):
        p = Popen(['nmcli', '-m', 'multiline'] + options, stdout=PIPE, stderr=PIPE)
        stdout, stderr = p.communicate()

        if p.returncode != 0:
            self.module.fail_json(
                msg='Non-zero return running nmcli: %s' % stderr,
                rc=p.returncode,
                out=stdout,
                err=stderr
            )

        return stdout.decode('utf-8')

    def _connections(self):
        stdout = self._run_nmcli(options=['c'])
        self.nmcli_facts['connections'] = []
        con_details = {}
        for line in stdout.strip().split("\n"):
            line_tokens = line.split()
            if line_tokens[0] == "NAME:":
                if con_details:
                    self.nmcli_facts['connections'].append(con_details)
                con_details = {}
                con_details['name'] = " ".join(line_tokens[1:])
            else:
                con_details[line_tokens[0].lower().strip(':')] = " ".join(line_tokens[1:])
        if con_details:
            self.nmcli_facts['connections'].append(con_details)
        return True

    def _devices(self):
        stdout = self._run_nmcli(options=['d'])
        self.nmcli_facts['devices'] = []
        device_details = {}
        for line in stdout.strip().split("\n"):
            line_tokens = line.split()
            if line_tokens[0] == "DEVICE:":
                if device_details:
                    self.nmcli_facts['devices'].append(device_details)
                device_details = {}
                device_details['device'] = " ".join(line_tokens[1:])
            else:
                device_details[line_tokens[0].lower().strip(':')] = " ".join(line_tokens[1:])
        if device_details:
            self.nmcli_facts['devices'].append(device_details)
        return True

    def get_facts(self):
        return self.nmcli_facts


def main():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    nmcli = Nmcli()
    nmcli_facts = nmcli.get_facts()
    module.exit_json(changed=False, ansible_facts={'nmcli_facts': nmcli_facts})


if __name__ == '__main__':
    main()
