# /etc/profile.d/iag.sh - set default IAG profile settings

# Enforce a session timeout after 15 minutes of inactivity
TMOUT=900

# Add timestamp to shell history
HISTTIMEFORMAT="%d-%b-%Y %T "

export TMOUT HISTTIMEFORMAT
