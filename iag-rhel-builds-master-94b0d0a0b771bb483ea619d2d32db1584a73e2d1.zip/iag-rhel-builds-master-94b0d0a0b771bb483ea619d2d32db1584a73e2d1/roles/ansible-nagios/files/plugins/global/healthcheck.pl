#!/usr/bin/perl
use strict qw/vars subs/;

my $commandVerb = lc(shift) or usage();
my $action;
if ($commandVerb eq '-action') {
   $action = lc(shift) or usage();
   ($action eq 'healthcheck') || ($action eq 'add_prd') || ($action eq 'add_pre')  || ($action eq 'add_dev') || ($action eq 'remove') || usage();
} else {
   usage();
}

&{$action}();
exit;

sub usage() {
   print "Usage: $0 -action (healthcheck | add_prd | add_pre | remove)\n";
   exit 3;
}

sub healthcheck() {
   my @output = `sudo /sbin/nagios -v /etc/nagios/nagios.cfg`;
   my $output = lc(join('###', @output));
   my %total;
   $total{$1} = $2 while ($output=~ /###total (warnings|errors):.*?(\d+)/g);
   $total{ok} = 1 if ($output =~ /###things look okay - no serious problems were detected during the pre-flight check/);
   my $checkIt = `grep  'ServerLocation='  /usr/lib64/nagios/plugins/notifications/ppi/ppi.cfg`; 
   $checkIt =~ s/ServerLocation=//; $checkIt =~ s/\..*$//;
   if ($total{errors}) {
      print "CRITICAL\n";
   } elsif ($total{warnings}) {
      print "WARNING\n";
   } elsif (!$total{ok}) {
      print "UNKNOWN\n";
   } else {
      print "OK ${checkIt}\n";
   }
}

sub add_prd() {
   system('cp /usr/lib64/nagios/plugins/notifications/ppi/ppi.cfg_prd /usr/lib64/nagios/plugins/notifications/ppi/ppi.cfg') == 0
      or die "add_prd CRITICAL: cp of ppi.cfg_prd file failed: $?";

   my $checkIt = `grep -c 'ServerLocation=vhprdap.baplc.com'  /usr/lib64/nagios/plugins/notifications/ppi/ppi.cfg`;
   die "add_prd CRITICAL: checkit grep for ServerLocation value did not match: grep-c = ${checkIt}" unless ($checkIt == 1);
   print "OK\n";
}

sub add_pre() {
   system('cp /usr/lib64/nagios/plugins/notifications/ppi/ppi.cfg_pre /usr/lib64/nagios/plugins/notifications/ppi/ppi.cfg') == 0
      or die "add_pre CRITICAL: cp of ppi.cfg_pre file failed: $?";

   my $checkIt = `grep -c 'ServerLocation=vhuatap.baplc.com'  /usr/lib64/nagios/plugins/notifications/ppi/ppi.cfg`;
   die "add_pre CRITICAL: checkit grep for ServerLocation value did not match: grep-c = ${checkIt}" unless ($checkIt == 1);
   print "OK\n";
}

sub add_dev() {
   system('cp /usr/lib64/nagios/plugins/notifications/ppi/ppi.cfg_dev /usr/lib64/nagios/plugins/notifications/ppi/ppi.cfg') == 0
      or die "add_dev CRITICAL: cp of ppi.cfg_dev file failed: $?";

   my $checkIt = `grep -c 'ServerLocation=vhdevap.baplc.com'  /usr/lib64/nagios/plugins/notifications/ppi/ppi.cfg`;
   die "add_dev CRITICAL: checkit grep for ServerLocation value did not match: grep-c = ${checkIt}" unless ($checkIt == 1);
   print "OK\n";
}

sub remove() {
   system('cp /usr/lib64/nagios/plugins/notifications/ppi/ppi.cfg_remove /usr/lib64/nagios/plugins/notifications/ppi/ppi.cfg') == 0
      or die "remove CRITICAL: cp of ppi.cfg_remove file failed: $?";

   my $checkIt = `grep -Ec 'ServerLocation=vhdevap0[12].baplc.com'  /usr/lib64/nagios/plugins/notifications/ppi/ppi.cfg`;
   die "remove CRITICAL: checkit grep for ServerLocation value did not match: grep-c = ${checkIt}" unless ($checkIt == 1);
   print "OK\n";
}
