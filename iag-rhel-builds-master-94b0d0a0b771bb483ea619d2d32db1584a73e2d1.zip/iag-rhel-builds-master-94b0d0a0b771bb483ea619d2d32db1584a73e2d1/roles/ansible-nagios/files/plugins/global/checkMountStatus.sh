#!/bin/bash
usage()
{
        sed -e 's/^    //'<<EndUsage
        Usage:
         checkMountStatus.sh [-h] [-p filesystem [-w ] [-c ]
         checkMountStatus.sh -p /ci/jbossnfs -w 1 -c ''
         checkMountStatus.sh -p /ci/jbossnfs -w '' -c 1


EndUsage
}

WARN_ARG=""
CRIT_ARG=""
COMMAND=NONE
RET_VAL=0
ECHO_VAL=
while getopts "Vvhp:w:c:" Option
do
        case $Option in
                h)
                        help
                        ;;
                w)
                        WARN_ARG=$OPTARG
                        ;;
                c)
                        CRIT_ARG=$OPTARG
                        ;;
                p)
                        COMMAND=$OPTARG
                        ;;
                ?)
                        usage
                        exit 2
                        ;;
        esac
done

#checking warning or critical 
if [[ -z "$WARN_ARG" ]] && [[ -z "$CRIT_ARG" ]]; then
    echo "Missing Warning/Critical alert setting"
    RET_VAL=3
fi

if grep -qs "${COMMAND}" /proc/mounts; then
    RET_VAL=0
    ECHO_VAL="${COMMAND} is  mounted."
else
    if [[ -n "$CRIT_ARG" ]]; then
  	RET_VAL=2
    else    
  	RET_VAL=1
    ECHO_VAL="${COMMAND} is not mounted."
    fi
fi
echo "$ECHO_VAL"
exit $RET_VAL
