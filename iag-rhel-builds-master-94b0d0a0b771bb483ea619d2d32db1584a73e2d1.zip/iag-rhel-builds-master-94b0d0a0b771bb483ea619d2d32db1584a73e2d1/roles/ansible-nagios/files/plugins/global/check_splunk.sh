#!/bin/sh
if  [ -f /opt/splunk/bin/splunk ]; then
    sudo -u splunk -H /opt/splunk/bin/splunk status
    RESULT=$?
else
    sudo -u splunk -H /opt/splunkforwarder/bin/splunk status
    RESULT=$?
fi
if [[ $(expr ${RESULT}) -eq 0 ]]; then
    RET_VAL=0;
    ECHO_VAL="OK - $RESULT"
else
    sudo -u splunk -H /opt/splunkforwarder/bin/splunk restart
    sleep 10
    sudo -u splunk -H /opt/splunkforwarder/bin/splunk status
    RESULT=$?
    if [[ $(expr ${RESULT}) -eq 0 ]]; then
    	RET_VAL=0;
    	ECHO_VAL="OK - $RESULT"
    else
    	ECHO_VAL="CRITICAL - $RESULT"
    	RET_VAL=2;
    fi
fi
echo "$ECHO_VAL"
exit $RET_VAL
