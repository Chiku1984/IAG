#!/bin/sh

PROGNAME=`basename $0`
VERSION="Version 1.0"

ST_OK=0
ST_WR=1
ST_CR=2
ST_OK=3

print_version() {
    echo "$PROGNAME $VERSION"
}

print_help() {
    print_version
    echo "$PROGNAME is a Nagios plugin to check whether ASR (Automatic System Recover)"
    echo "is enabled in the BIOS and disable it if it is"
    exit $ST_OK
}

check_asr() {

declare __HPASMCLI=/sbin/hpasmcli
declare __HOST=`/bin/uname -n`
declare __DAEMON1=hpasmlited
declare __DAEMON2=hpasmxld

if [ -x $__HPASMCLI ] && pgrep $__DAEMON1 >/dev/null || pgrep $__DAEMON2 >/dev/null; then
    if $__HPASMCLI -s "show asr" | awk /"ASR is currently"/'{print $4}' | sed s'/\.//' | grep enabled >/dev/null 2>&1; then
        $__HPASMCLI -s "disable ASR" >/dev/null 2>&1
        if $__HPASMCLI -s "show asr" | awk /"ASR is currently"/'{print $4}' | sed s'/\.//' | grep enabled >/dev/null 2>&1; then
	    echo -e "ERROR - Unable to disable ASR on $__HOST"
	    exit $ST_CR
	else
	    echo -e "OK - ASR disabled on $__HOST"
	    exit $ST_OK
	fi
    else
	echo -e "OK - ASR already disabled on $__HOST"
	exit $ST_OK
    fi
else
    echo -e "ERROR - Either $__HPASMCLI not found or $__DAEMON process not running on $__HOST"
    exit $ST_WR
fi
}
if (( $# > 0 )); then
    case "$1" in
        --help|-h)
            print_help
            exit $ST_OK
            ;;
        --version|-v)
            print_version
            exit $ST_OK
            ;;
        *)
            check_asr
            ;;
    esac
else
   check_asr
fi
