#!/usr/bin/perl

use strict;

use Getopt::Long;
use Data::Dumper;

my ($debug, $service, $state);
use constant {
 OK       => 0,
 WARNING  => 1,
 CRITICAL => 2,
 UNKNOWN  => 3
};

GetOptions( "debug"     => \$debug,
            "service=s" => \$service,
            "state=s"   => \$state
);

if ( ! $service || ! $state || $state !~ /^up$|^down$/ ) { &usage(); }

my $status="UNKNOWN";
my $checkString="";

open(FW, ">>/var/log/nagios/spool/chkservice.log");
printf(FW time()." - service=${service} state=${state}\n");
close(FW);

my @data = split(/\n/, `sudo /sbin/service $service status 2>&1`);
if ( grep(/is running|is stopped/, @data) ) {
    $checkString = (grep(/is running|is stopped/, @data))[0];
    if ( ($state eq "up"   && $checkString =~ /is running/) ||
         ($state eq "down" && $checkString =~ /is stopped/) ) {
        $status="OK";
    } else {
        $status="CRITICAL";
    }
} elsif ( grep(/^\s+Active: /, @data) ) {
    $checkString = (grep(/^\s+Active: /, @data))[0];
    $checkString =~s/^\s+//;
    if ( ($state eq "up"   && $checkString =~ /Active: active /) ||
         ($state eq "down" && $checkString =~ /Active: inactive /) ) {
        $status="OK";
    } else {
        $status="CRITICAL";
    }
} else {
    printf("SERVICE UNKOWN ".join("\n", @data)."; | $service=unknown\n");
    exit UNKNOWN;
}

printf("SERVICE $status Service $service ($checkString)\n");
if ( $status ne "OK" ) {
    exit CRITICAL;
}

exit OK;

sub usage() {
open(FW, ">>/var/log/nagios/spool/chkservice.log");
printf(FW time()." usage service=${service} state=${state}\n");
close(FW);
    printf("Usage:    check_service.pl -service <name> -state <state>\n\n");
    printf("              -service     The name of the service to be checked\n");
    printf("              -state       The state the service should be in eith up or down\n\n");
    printf("SERVICE UNKOWN - Usage issue;| usage=\n");
    exit UNKNOWN;
}

1;
