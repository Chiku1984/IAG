#!/usr/bin/perl
#===============================================================================
#
#         FILE:  check_file.pl
#
#        USAGE:  ./check_file.pl  
#
#  DESCRIPTION:  Nagios plugin to check file update/existence/content
#===============================================================================

use warnings;
use strict;
use Getopt::Long;

my %RETCODES = ('OK' => 0, 'WARNING' => 1, 'CRITICAL' => 2, 'UNKNOWN' => 3);
my ($fileName,$type,$alert);

# Help
sub help
{
    print "Usage : check_file.pl -f file -p [content=string |existence=yes |update=updatetime] -a [w/c]  [-h]\n\n";
	print "Options :\n";
    print " -f\n\tFull path to file\n";
    print " -p\n\tContent, Existence or UpdateTime in seconds\n";
    print " -h, --help\n\tPrint this help screen\n";
    print "\nExample : check_file.pl -f /home/rtmobappcic/monitoring/logs/alarmfile.log -p content=root\n";
    print "\nExample : check_file.pl -f /home/rtmobappcic/monitoring/logs/alarmfile.log -p update=900\n";
    print "\nExample : check_file.pl -f /home/rtmobappcic/monitoring/logs/alarmfile.log -p existence=yes\n";
    print "\nExample : check_file.pl -f /home/rtmobappcic/monitoring/logs/alarmfile.log.%YY%MM%DD -p existence=no\n";
    exit $RETCODES{"UNKNOWN"};
}

sub check_args 
 {
    help if !(@ARGV);
      
    # Set options
    GetOptions( 	"help|h"    => \&help,
                	"f=s"   	=> \$fileName,
                	"p=s"   	=> \$type,
                	"a=s"   	=> \$alert);

    unless ( $fileName and $type and $alert) {
    	&help;
    }
    if ( $fileName =~ /%/ ) {
	my ( $day, $mon, $year ) = (localtime)[3..5];
	$year=sprintf '20%02d',$year % 100;
	$mon= sprintf '%02d',$mon+1;
	$day=sprintf '%02d',$day;
	$fileName=~s/%YY/$year/;
    	$fileName=~s/%MM/$mon/;
	$fileName=~s/%DD/$day/;
    }
    if ( $type =~ /existence=/ ) {
	my $exType=$type; $exType=~ s/.*existence=//;
 	existence_check($fileName,$exType,$alert);
    } elsif ( $type =~ /update=/ ) {
	my $diff=$type; $diff=~ s/.*update=//;
        update_check($fileName,$diff,$alert);
    } elsif ( $type =~ /content=/ ) {
	my $checkString=$type; $checkString=~ s/.*content=//;
	content_check($fileName,$checkString,$alert);
    }
       
}

sub update_check {
    my $fileName=shift;
    my $diff=shift;
    my $diffMins=int($diff/60);
    my $aType=shift;
    (my $mtime) = (stat($fileName))[9];
    if ( (time() - $mtime) > $diff ) {
	if ( $aType =~ /c|C/ ) {
	    print "CRITICAL:$fileName is older than $diffMins minutes\n";
	    exit $RETCODES{"CRITICAL"};
	} else {
	    print "WARNING:$fileName is older than $diffMins minutes\n";
	    exit $RETCODES{"WARNING"};
	}
    } else {
	print "OK: $fileName is uptodate\n";
	exit $RETCODES{"OK"};
    }
}

sub existence_check {
    my $fileName=shift;
    my $exType=shift;
    my $aType=shift;
    #printf("fileName:$fileName, type:$exType alert:$aType\n");
    if ( -f "$fileName" ) {
	if ($exType =~ /[y|Y]es/ ) {
	    print "OK: $fileName detected\n";
	    exit $RETCODES{"OK"};
	} else {
	    if ( $aType =~ /c|C/ ) {
	        print "CRITICAL: $fileName detected\n";
	        exit $RETCODES{"CRITICAL"};
	    } else {
	        print "WARNING: $fileName detected\n";
	        exit $RETCODES{"WARNING"};
	    }
    	}
    } else {
	if ($exType =~ /[n|N]o/ ) {
	    print "OK: $fileName not detected\n";
	    exit $RETCODES{"OK"};
	} else {
	    if ( $aType =~ /c|C/ ) {
	        print "CRITICAL: $fileName detected\n";
	        exit $RETCODES{"CRITICAL"};
	    } else {
	        print "WARNING: $fileName detected\n";
	        exit $RETCODES{"WARNING"};
	    }
    	}
    }
}

sub content_check {
    my $fileName=shift;
    my $checkString=shift;
    my $aType=shift;
    
    if (!open(FR, "<$fileName")) {
	print "Cant open $fileName: $fileName\n";
	exit $RETCODES{"WARNING"};
    }
    my @data=<FR>; close(FR);
    if ( grep(/$checkString/,@data) ) {
	print "$fileName contains $checkString\n";
	if ( $aType eq "c" ) {
	    print "CRITICAL: $fileName contains '$checkString'\n";
	    exit $RETCODES{"CRITICAL"};
	} else {
	    print "WARNING: $fileName contains '$checkString'\n";
	    exit $RETCODES{"WARNING"};
	}
    } else {
	print "OK:$fileName does not contain '$checkString'\n";
	exit $RETCODES{"OK"};
    }
}

check_args;
