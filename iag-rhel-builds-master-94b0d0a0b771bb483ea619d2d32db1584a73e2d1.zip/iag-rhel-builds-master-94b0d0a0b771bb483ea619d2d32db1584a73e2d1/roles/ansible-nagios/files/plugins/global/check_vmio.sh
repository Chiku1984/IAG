#!/bin/bash

########################################################################################################
#    Nagios VMIO-Plugin - Checks Virtual Memory and Input / Output Data from Linux and Solaris Systems #
#    Copyright (C) 2008  ElectronicPartner Handel GmbH & Matthias Clemen                               #
#                                                                                                      #
#    This program is free software: you can redistribute it and/or modify                              #
#    it under the terms of the GNU General Public License Version 3 as published by                    #
#    the Free Software Foundation.                                                                     #
#                                                                                                      #
#    This program is distributed in the hope that it will be useful,                                   #
#    but WITHOUT ANY WARRANTY; without even the implied warranty of                                    #
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                     #
#    GNU General Public License Version 3 for more details.                                            #
#                                                                                                      #
#    You should have received a copy of the GNU General Public License                                 #      
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.                             #
########################################################################################################

################################################################################
#      VMIO PLUGIN                                                             #
################################################################################
# USAGE: check_vmio.sh [-Vh] [-p parameter [-w threshold] [-c threshold]]     #
#                                                                              #
#     Parameters:                                                              #
#	                                                                       #
#	 WAIT_TIME                                                             #
#	     If set the plugin will show the average wait time IO inputs are   #
#	     in queue.                                                         #
#	                                                                       #
#	 PROCESS_QUEUE                                                         #
#	     If set the plugin will show the average number of processes in    #
#	     queue.                                                            #
#	                                                                       #
#	 PROCESS_BLOCKED                                                       #
#	     If set the plugin will show the average number of blocked         #
#	     processes.                                                        #
#	                                                                       #
#	 SWAP_AVAIL                                                            #
#	     If set the plugin will show the average aviable Swap.             #
#	                                                                       #
#	 PAGE_IN                                                               #
#	     If set the plugin will show the average number of pages in.       #
#	                                                                       #
#	 PAGE_OUT                                                              #
#	     If set the plugin will show the average number of pages out.      #
#	                                                                       #
#	 SYS_CPU_TIME                                                          #
#	     If set the plugin will analye the average CPU-time used by the    #
#	     system.                                                           #
#                                                                              #
#	Options:                                                               #
#                                                                              #
#	 -h                                                                    #
#	     Displays this help dialog                                         #
#	                                                                       #
#	 -V                                                                    #
#	     Displays Version and Credits                                      #
#                                                                              #
#	 -p                                                                    #
#	     sets which value will be observed. For mor information see        #
#             Parameters below.                                                #
#                                                                              #
#	 -w                                                                    #
#	     sets the warning thredhold. Default is 0:0. For more information  #
#	     see Nagios Developer guidlines or see Thredholds below.           #
#                                                                              #
#	 -c                                                                    #
#	     sets the critical thredhold. Default is 0:0. For more information #
#	     see Nagios Developer guidlines or see Thredholds below.           #
#                                                                              #
#	Warn/Crit Formate note:                                                #
#	1.	start <= end                                                   #
#	2.	start and : is not required if start=0                         #
#	3.	if range is of format "start:" and end is not specified,       #
#		assume end is infinity                                         #
#	4.	to specify negative infinity, use "~"                          #
#	5.	alert is raised if metric (VALUE) is outside start and end     #
#		range (inclusive of endpoints)                                 #
#	6.	if range starts with "@", then alert if inside this range      #
#		(inclusive of endpoints)                                       #
#                                                                              #
#	Examples:                                                              #
#	check_vmio.sh -p WAIT_TIME -w 1 -c 2                                   #
#	check_vmio.sh -p SWAP_AVIL -w 1000000 -c 19999999                      #
#                                                                              #
################################################################################

version ()
{
	sed -e 's/^    //'<<EndVersion
	Nagios VMIO-Plugin
	Version 1.0
	Author: Matthias Clemen (matthias-clemen@gmx.de)
	Release date:
	Last updated:
	Licence: GPL V.3 Copyright (C) 2008  
		ElectronicPartner Handel GmbH & 
		Matthias Clemen 



EndVersion
	exit 1
}
	
help()
{
	sed -e 's/^    //'<<EndHelp
	Usage: 
	  check_vmio.sh [-Vh] [-p parameter [-w threshold] [-c threshold]]
	
	
	Options:

	 -h
	     Displays this help dialog
	 
	 -V
	     Displays Version and Credits
	     
	 -p
	     sets which value will be observed. For mor information see
             Parameters below.

	 -w
	     sets the warning thredhold. Default is 0:0. For more information
	     see Nagios Developer guidlines or see Thredholds below.

	 -c
	     sets the critical thredhold. Default is 0:0. For more information
	     see Nagios Developer guidlines or see Thredholds below.

	Parameters:
	
	 WAIT_TIME
	     If set the plugin will show the average wait time IO inputs are
	     in queue.
	     
	 PROCESS_QUEUE
	     If set the plugin will show the average number of processes in 
	     queue.
	     
	 PROCESS_BLOCKED
	     If set the plugin will show the average number of blocked 
	     processes.
	     
	 SWAP_AVAIL
	     If set the plugin will show the average aviable Swap.
	     Thredholds in kB.
	     
	 PAGE_IN
	     If set the plugin will show the average number of pages in.
	     
	 PAGE_OUT
	     If set the plugin will show the average number of pages out.
	     
	 SYS_CPU_TIME
	     If set the plugin will analye the average CPU-time used by the
	     system.

	
 	Thredholds:
	
	Syntax:
		[@]start:end	

 	1.	start <= end
 	2.	start and : is not required if start=0
 	3.	if range is of format "start:" and end is not specified,
 		assume end is infinity
 	4.	to specify negative infinity, use "~"
 	5.	alert is raised if metric (VALUE) is outside start and end
 		range (inclusive of endpoints)
 	6.	if range starts with "@", then alert if inside this range
 		(inclusive of endpoints)


EndHelp
	exit 1
}

usage()
{
	sed -e 's/^    //'<<EndUsage
	Usage: 
	 check_vmio.sh [-Vh] [-p parameter [-w threshold] [-c threshold]]

	Prameters:
			
	 -> WAIT_TIME
	 -> PROCESS_QUEUE
	 -> PROCESS_BLOCKED
	 -> SWAP_AVAIL
	 -> PAGE_IN
	 -> PAGE_OUT
	 -> SYS_CPU_TIME

	try check_vmio.sh -h for more infomation.


EndUsage
}


################################################################################
#      Value Test Funktion                                                     #
################################################################################
# USAGE: test VALUE WARN CRIT [-v]                                             #
#                                                                              #
#	VALUE: The value that will be tested. Allowed are all integer values.  #
#	WARN : contains the threshold and ranges for warning output            #
#	CRIT : contains the threshold and ranges for Critical output           #
#       -v   : id set a colored verbose output will be displayed               #
#              If you enter -vv more will be shown                             #
#                                                                              #
#	Return Values:                                                         #
#                                                                              #
#	OK:	0                                                              #
#	WARN:	1                                                              #
#	CRIT:	2                                                              #
#                                                                              #
#	Note threshold and ranges:                                             #
#	allowed format:		[@]start:end                                   #
#                                                                              #
#	Formate note:                                                          #
#	1.	start <= end                                                   #
#	2.	start and : is not required if start=0                         #
#	3.	if range is of format "start:" and end is not specified,       #
#		assume end is infinity                                         #
#	4.	to specify negative infinity, use "~"                          #
#	5.	alert is raised if metric (VALUE) is outside start and end     #
#		range (inclusive of endpoints)                                 #
#	6.	if range starts with "@", then alert if inside this range      #
#		(inclusive of endpoints)                                       #
#                                                                              #
#	Examples:                                                              #
#	VALUE	WARN	CRIT	RESULT                                         #
#	-1	10	20	crit                                           #
#	20	10	20:	warn                                           #
#	3	~:10	~:20	OK                                             #
#	5	@5:10	1:20	warn                                           #
#	16	5:10	1:20	warn                                           #
#	10	@~:9	@11:	OK                                             #
#                                                                              #
################################################################################
WARN_INVERSE=0
WARN_MIN_VALUE=0
WARN_MAX_VALUE=0
CRIT_INVERSE=0
CRIT_MIN_VALUE=0
CRIT_MAX_VALUE=0

function test {
	# setting Path 
	AWK="awk"
	CUT="cut"
	ECHO="echo"
	# Setting the Verbose output
	if [[ (-n $4) && ($4 = "-v") ]];then
		# be verbose
		VERB=1
	elif [[ (-n $4) && ($4 = "-vv") ]];then
		# be more verbose
		VERB=2
	else
		# or not
		VERB=0
	fi
	# verbose Output
	if [ 1 -eq $VERB ]; then
	       printf "TEST:\t$1\t$2\t$3\t"
        elif [ 2 -eq $VERB ]; then
	        $ECHO 
	        $ECHO
		printf "VALUE: $1\t WARN: $2\tCRIT: $3\t\n"
        fi
	# Inizialising Variables
	VALUE=$1
	WARN_INVERSE=0 
	CRIT_INVERSE=0
	# warning thresholds
	WARN_MIN_VALUE=0
	WARN_MAX_VALUE=0
	# crit thresholds
	CRIT_MIN_VALUE=0
	CRIT_MAX_VALUE=0
	
	
	####################
	# Warn Processing  #
	####################
	# handle the @
	if [[ $2 = @* ]]; then
		#$ECHO "starts with AT"
		WARN_INVERSE=1
		ARG=$( $ECHO $2 | $AWK '{print substr($0,2)}' )
	else
		ARG=$2
	fi
	# threshold Processing
	if [[ $ARG = *:* ]]; then
		# Splitting $ARG string into Min and Max part
		MIN=$($ECHO $ARG | $CUT -d':' -f1)
		MAX=$($ECHO $ARG | $CUT -d':' -f2)
		# min values
		if [ $MIN = \~ ]; then
			WARN_MIN_VALUE="inv";
		else
			WARN_MIN_VALUE=$MIN
		fi
		
		# max values
		if [ !$MAX -a $MAX = '' ]; then
			WARN_MAX_VALUE="inv";
		else
			WARN_MAX_VALUE=$MAX
		fi
		
	else
		WARN_MIN_VALUE=0
		WARN_MAX_VALUE=$ARG
	fi
	
	####################
	# crit Processing  #
	####################
	# handle the @
	if [[ $3 = @* ]]; then
		#$ECHO "starts with AT"
		CRIT_INVERSE=1
		ARG=$( $ECHO $3 | $AWK '{print substr($0,2)}' )
	else
		ARG=$3
	fi
	# threshold Processing
	if [[ $ARG = *:* ]]; then
		# Splitting $ARG string into Min and Max part
		MIN=$($ECHO $ARG | $CUT -d':' -f1)
		MAX=$($ECHO $ARG | $CUT -d':' -f2)
		# min values
		if [ $MIN = \~ ]; then
			CRIT_MIN_VALUE="inv";
		else
			CRIT_MIN_VALUE=$MIN
		fi
		
		# max values
		if [ !$MAX -a $MAX = '' ]; then
			CRIT_MAX_VALUE="inv";
		else
			CRIT_MAX_VALUE=$MAX
		fi
	else
		CRIT_MIN_VALUE=0
		CRIT_MAX_VALUE=$ARG
	fi
	
	if [ 2 -eq $VERB ]; then
		$ECHO WARN_INVERSE=$WARN_INVERSE
		$ECHO WARN_MIN_VALUE=$WARN_MIN_VALUE
		$ECHO WARN_MAX_VALUE=$WARN_MAX_VALUE
		$ECHO CRIT_INVERSE=$CRIT_INVERSE
		$ECHO CRIT_MIN_VALUE=$CRIT_MIN_VALUE
		$ECHO CRIT_MAX_VALUE=$CRIT_MAX_VALUE
	fi
	
	
	
	
	
	
	
	################################
	#######  Auswertung    #########
	################################

	# CRIT aus wertung
	# Max infinity     
	if [[ ($CRIT_INVERSE -eq 0 ) &&\
	      ($CRIT_MAX_VALUE == "inv") &&\
	      ($VALUE -lt $CRIT_MIN_VALUE) ]]; then
		# Verbose output
		if [ $VERB -ge 1 ]; then
			$ECHO "[0;31;40mcrit[0;97;40m"
		fi
		# CRIT return
		return 2
	# Min infinity     
	elif [[ ($CRIT_INVERSE -eq 0 ) &&\
	       	($CRIT_MIN_VALUE == "inv") &&\
	       	($VALUE -gt $CRIT_MAX_VALUE) ]]; then
		# Verbose output
		if [ $VERB -ge 1 ]; then
			$ECHO "[0;31;40mcrit[0;97;40m"
		fi
		# CRIT return
		return 2
	# normal processing
	elif [[ ($CRIT_INVERSE -eq 0 ) &&\
	       	($CRIT_MAX_VALUE != "inv") &&\
	       	($CRIT_MIN_VALUE != "inv") &&\
	      	(($VALUE -lt $CRIT_MIN_VALUE) ||\
	       	 ($VALUE -gt $CRIT_MAX_VALUE)) ]]; then
		# Verbose output
		if [ $VERB -ge 1 ]; then
			$ECHO "[0;31;40mcrit[0;97;40m"
		fi
		# CRIT return
		return 2

	# @Crit aus wertung
	# Max infinity     
	elif [[ ($CRIT_INVERSE -eq 1 ) &&\
	       	($CRIT_MAX_VALUE == "inv") &&\
	       	($VALUE -ge $CRIT_MIN_VALUE) ]]; then
		# Verbose output
		if [ $VERB -ge 1 ]; then
			$ECHO "[0;31;40mcrit[0;97;40m"
		fi
		# CRIT return
		return 2
	# Min infinity     
	elif [[ ($CRIT_INVERSE -eq 1 ) &&\
	       	($CRIT_MIN_VALUE == "inv") &&\
	       	($VALUE -le $CRIT_MAX_VALUE) ]]; then
		# Verbose output
		if [ $VERB -ge 1 ]; then
			$ECHO "[0;31;40mcrit[0;97;40m"
		fi
		# CRIT return
		return 2
	# normal processing
	elif [[ ($CRIT_INVERSE -eq 1 ) &&\
	       	($CRIT_MAX_VALUE != "inv") &&\
	       	($CRIT_MIN_VALUE != "inv") &&\
	      	(($VALUE -ge $CRIT_MIN_VALUE) &&\
	       	 ($VALUE -le $CRIT_MAX_VALUE)) ]]; then
		# Verbose output
		if [ $VERB -ge 1 ]; then
			$ECHO "[0;31;40mcrit[0;97;40m"
		fi
		# CRIT return
		return 2


	# warn aus wertung
	# Max infinity
	elif [[ ($WARN_INVERSE -eq 0 ) &&\
	       	($WARN_MAX_VALUE == "inv") &&\
	       	($VALUE -lt $WARN_MIN_VALUE) ]]; then
		# Verbose output
		if [ $VERB -ge 1 ]; then
			$ECHO "[0;33;40mwarn[0;97;40m"
		fi
		# WARN return
		return 1
	# Min infinity
	elif [[ ($WARN_INVERSE -eq 0 ) &&\
	       	($WARN_MIN_VALUE == "inv") &&\
	       	($VALUE -gt $WARN_MAX_VALUE) ]]; then
		# Verbose output
		if [ $VERB -ge 1 ]; then
			$ECHO "[0;33;40mwarn[0;97;40m"
		fi
		# WARN return
		return 1
	# normal processing
	elif [[ ($WARN_INVERSE -eq 0 ) &&\
	       	($WARN_MAX_VALUE != "inv") &&\
	      	($WARN_MIN_VALUE != "inv") &&\
	       	(($VALUE -lt $WARN_MIN_VALUE) ||\
	       	 ($VALUE -gt $WARN_MAX_VALUE)) ]]; then
		# Verbose output
		if [ $VERB -ge 1 ]; then
			$ECHO "[0;33;40mwarn[0;97;40m"
		fi
		# WARN return
		return 1

	# @warn aus wertung
	# Max infinity
	elif [[ ($WARN_INVERSE -eq 1 ) &&\
	       	($WARN_MAX_VALUE == "inv") &&\
	       	($VALUE -ge $WARN_MIN_VALUE) ]]; then
		# Verbose output
		if [ $VERB -ge 1 ]; then
			$ECHO "[0;33;40mwarn[0;97;40m"
		fi
		# WARN return
		return 1
	# Min infinity
	elif [[ ($WARN_INVERSE -eq 1 ) &&\
		($WARN_MIN_VALUE == "inv") &&\
	       	($VALUE -le $WARN_MAX_VALUE) ]]; then
		# Verbose output
		if [ $VERB -ge 1 ]; then
			$ECHO "[0;33;40mwarn[0;97;40m"
		fi
		# WARN return
		return 1
	# normal processing
	elif [[ ($WARN_INVERSE -eq 1 ) &&\
	       	($WARN_MAX_VALUE != "inv") &&\
	       	($WARN_MIN_VALUE != "inv") &&\
	       	(($VALUE -ge $WARN_MIN_VALUE) &&\
	       	 ($VALUE -le $WARN_MAX_VALUE)) ]]; then
		# Verbose output
		if [ $VERB -ge 1 ]; then
			$ECHO "[0;33;40mwarn[0;97;40m"
		fi
		# WARN return
		return 1

	# OK no error
	else
		# Verbose output
		if [ $VERB -ge 1 ]; then
		       	$ECHO "[0;92;40mOK[0;97;40m"
		fi
		# OK return
		return 0
	fi
}

################################
###### TESTS          ##########
################################
#for (( i = -5; i < 25; i++ )); do
#	test $i 10 20 $1;
#done
#$ECHO
#for (( i = -5; i < 25; i++ )); do
#	test $i 10 20: $1;
#done
#$ECHO
#for (( i = -5; i < 25; i++ )); do
#	test $i '~:10' '~:20' $1;
#done
#$ECHO
#for (( i = -5; i < 25; i++ )); do
#	test $i 5:10 1:20 $1;
#done
#$ECHO
#for (( i = -5; i < 25; i++ )); do
#	test $i @5:10 1:20 $1;
#done
#$ECHO
#for (( i = -5; i < 25; i++ )); do
#	test $i @5:10 @8:20 $1;
#done
#$ECHO
#for (( i = -5; i < 25; i++ )); do
#	test $i 0 1 $1;
#done
#$ECHO
# min 1 parameter
if [[ $# -lt 1 ]];then 
	usage
	exit 2
fi

#defaults
WARN_ARG=0
CRIT_ARG=0
PARAMETER=NONE

#Splitting Parameter
while getopts "Vvhp:w:c:" Option 
do
	case $Option in
		h)
			help
			;;
		V)
			version
			;;
		w)
			WARN_ARG=$OPTARG
			;;
		c)
			CRIT_ARG=$OPTARG
			;;
		p)
			PARAMETER=$OPTARG
			;;
		?)
			usage
			exit 2
			;;
	esac
done

#Checking range Syntax
if [ $(echo $WARN_ARG | awk '{if ($1~/^[@]?[0-9]+[:]?[0-9]*$/ || $1~/^[@]?[~][:]?[0-9]*$/) printf "%d",1; else printf "%d",0 }') -eq 0 ];then
	echo UNKNOWN WARNING RANGE - check your configuration
	usage
	exit 3
fi
if [ $(echo $CRIT_ARG | awk '{if ($1~/^[@]?[0-9]+[:]?[0-9]*$/ || $1~/^[@]?[~][:]?[0-9]*$/) printf "%d",1; else printf "%d",0 }') -eq 0 ];then
	echo UNKNOWN CRITICAL RANGE - check your configuration
	usage
	exit 3
fi

# parameter for iostat and vmstat
INTERVAL=1
COUNT=5

# default return values
RET_VAL=3
ECHO_VAL= 

# detecting the OS
OSSTRING=$(uname)
#echo $OSSTRING
if [[ $OSSTRING = "SunOS" ]]; then
	echo "SUNOS"

	# Handeling Actions
	case $PARAMETER in
		WAIT_TIME)
			# collecting Data
			RESULT=$(iostat $INTERVAL $COUNT)
			# removing header
			OUTPUT=$(echo "$RESULT"	| tail +3 | awk '{ printf "%d\n",$17 }')
			# calculating average value
			SUMME=0
			for i in $OUTPUT;
  			  do
    			    SUMME=$(expr $SUMME + $i)
  			  done
			AVG=$(expr ${SUMME} / ${COUNT})
			# checking threshold
			test $AVG $WARN_ARG $CRIT_ARG
			RET_VAL=$?
			# selecting output String (STATISINFORMATION | PERFORMANCEDATA)
			if [ $RET_VAL -eq 0 ]; then
				ECHO_VAL="OK - $AVG IO waittime|WAIT_TIME=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			elif [ $RET_VAL -eq 1 ]; then
				ECHO_VAL="WARNING - $AVG IO waittime|WAIT_TIME=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			else 
				ECHO_VAL="CRITICAL - $AVG IO waittime|WAIT_TIME=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			fi
			;;
		PROCESS_QUEUE)
			# collecting Data
			RESULT=$(vmstat $INTERVAL $COUNT)
			# removing header
			OUTPUT=$(echo "$RESULT"	| tail +3 | awk '{ printf "%d\n",$1 }')
			# calculating average value
			SUMME=0
			for i in $OUTPUT;
  			  do
    			    SUMME=$(expr $SUMME + $i)
  			  done
			AVG=$(expr ${SUMME} / ${COUNT})
			# checking threshold
			test $AVG $WARN_ARG $CRIT_ARG
			RET_VAL=$?
			# selecting output String (STATISINFORMATION | PERFORMANCEDATA)
			if [ $RET_VAL -eq 0 ]; then
				ECHO_VAL="OK - $AVG processes in queue|PROCESS_QUEUE=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			elif [ $RET_VAL -eq 1 ]; then
				ECHO_VAL="WARNING - $AVG processes in queue|PROCESS_QUEUE=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			else 
				ECHO_VAL="CRITICAL - $AVG processes in queue|PROCESS_QUEUE=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			fi
			;;
		PROCESS_BLOCKED)
			# collecting Data
			RESULT=$(vmstat $INTERVAL $COUNT)
			# removing header
			OUTPUT=$(echo "$RESULT"	| tail +3 | awk '{ printf "%d\n",$2 }')
			# calculating average value
			SUMME=0
			for i in $OUTPUT;
  			  do
    			    SUMME=$(expr $SUMME + $i)
  			  done
			AVG=$(expr ${SUMME} / ${COUNT})
			# checking threshold
			test $AVG $WARN_ARG $CRIT_ARG
			RET_VAL=$?
			# selecting output String (STATISINFORMATION | PERFORMANCEDATA)
			if [ $RET_VAL -eq 0 ]; then
				ECHO_VAL="OK - $AVG processes are blocked|PROCESS_BLOCKED=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			elif [ $RET_VAL -eq 1 ]; then
				ECHO_VAL="WARNING - $AVG processes are blocked|PROCESS_BLOCKED=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			else 
				ECHO_VAL="CRITICAL - $AVG processes are blocked|PROCESS_BLOCKED=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			fi
			;;
		SWAP_AVAIL)
			# collecting Data
			RESULT=$(vmstat $INTERVAL $COUNT)
			# removing header
			OUTPUT=$(echo "$RESULT"	| tail +3 | awk '{ printf "%d\n",$5 }')
			# calculating average value
			SUMME=0
			for i in $OUTPUT;
  			  do
    			    SUMME=$(expr $SUMME + $i)
  			  done
			AVG=$(expr ${SUMME} / ${COUNT})
			# checking threshold
			test $AVG $WARN_ARG $CRIT_ARG
			RET_VAL=$?
			
			# Getting total Swap
			OUTPUT=$(echo "$RESULT"	| tail +3 | awk '{ printf "%d\n",$4 }')
			SUMME=0
			for i in $OUTPUT;
  			  do
    			    SUMME=$(expr $SUMME + $i)
  			  done
			AVG_MAX=$(expr ${SUMME} / ${COUNT})
			# selecting output String (STATISINFORMATION | PERFORMANCEDATA)
			if [ $RET_VAL -eq 0 ]; then
				ECHO_VAL="OK - $AVG KB free Swap avial|SWAP_AVAIL=" $(expr ${AVG} \* ${1024} ) "B;"$(expr ${WARN_MIN_VALUE} \* 1024 )";"$(expr ${CRIT_MIN_VALUE} \* 1024 )";0;"$(expr ${AVG_MAX} \* 1024 )
			elif [ $RET_VAL -eq 1 ]; then
				ECHO_VAL="WARNING - $AVG KB free Swap avial|SWAP_AVAIL="$(expr ${AVG} \* 1024 )"B;"$(expr ${WARN_MIN_VALUE} \* 1024 )";"$(expr ${CRIT_MIN_VALUE} \* 1024 )";0;"$(expr ${AVG_MAX} \* 1024 )
			else 
				ECHO_VAL="CRITICAL - $AVG KB free Swap avial|SWAP_AVAIL="$(expr ${AVG} \* 1024 )"B;"$(expr ${WARN_MIN_VALUE} \* 1024 )";"$(expr ${CRIT_MIN_VALUE} \* 1024 )";0;"$(expr ${AVG_MAX} \* 1024 )
			fi
			;;
		PAGE_IN)
			# collecting Data
			RESULT=$(vmstat $INTERVAL $COUNT)
			# removing header
			OUTPUT=$(echo "$RESULT"	| tail +3 | awk '{ printf "%d\n",$8 }')
			# calculating average value
			SUMME=0
			for i in $OUTPUT;
  			  do
    			    SUMME=$(expr $SUMME + $i)
  			  done
			AVG=$(expr ${SUMME} / ${COUNT})
			# checking threshold
			test $AVG $WARN_ARG $CRIT_ARG
			RET_VAL=$?
			# selecting output String (STATISINFORMATION | PERFORMANCEDATA)
			if [ $RET_VAL -eq 0 ]; then
				ECHO_VAL="OK - $AVG pages in|PAGE_IN=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			elif [ $RET_VAL -eq 1 ]; then
				ECHO_VAL="WARNING - $AVG pages in|PAGE_IN=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			else 
				ECHO_VAL="CRITICAL - $AVG pages in|PAGE_IN=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			fi
			;;
		PAGE_OUT)
			# collecting Data
			RESULT=$(vmstat $INTERVAL $COUNT)
			# removing header
			OUTPUT=$(echo "$RESULT"	| tail +3 | awk '{ printf "%d\n",$9 }')
			# calculating average value
			SUMME=0
			for i in $OUTPUT;
  			  do
    			    SUMME=$(expr $SUMME + $i)
  			  done
			AVG=$(expr ${SUMME} / ${COUNT})
			# checking threshold
			test $AVG $WARN_ARG $CRIT_ARG
			RET_VAL=$?
			# selecting output String (STATISINFORMATION | PERFORMANCEDATA)
			if [ $RET_VAL -eq 0 ]; then
				ECHO_VAL="OK - $AVG pages out|PAGE_OUT=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			elif [ $RET_VAL -eq 1 ]; then
				ECHO_VAL="WARNING - $AVG pages out|PAGE_OUT=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			else 
				ECHO_VAL="CRITICAL - $AVG pages out|PAGE_OUT=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			fi
			;;
# NOT SUPPORTED
		# SCAN_RATE)
			# RESULT=$(vmstat $INTERVAL $COUNT)
			# OUTPUT=$(echo "$RESULT"	| tail +3 | awk '{ printf "%d\n",$12}')
			# SUMME=0
			# for i in $OUTPUT;
  			  # do
    			    # SUMME=$(expr $SUMME + $i)
  			  # done
			# AVG=$(expr ${SUMME} / ${COUNT})
			# test $AVG $WARN_ARG $CRIT_ARG
			# RET_VAL=$?
			# if [ $RET_VAL -eq 0 ]; then
				# ECHO_VAL="OK - $AVG Scan rate|SCAN_RATE=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			# elif [ $RET_VAL -eq 1 ]; then
				# ECHO_VAL="WARNING - $AVG Scan rate|SCAN_RATE=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			# else 
				# ECHO_VAL="CRITICAL - $AVG Scan rate|SCAN_RATE=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			# fi
			# ;;
		SYS_CPU_TIME)
			# collecting Data
			RESULT=$(vmstat $INTERVAL $COUNT)
			# removing header
			OUTPUT=$(echo "$RESULT"	| tail +3 | awk '{ printf "%d\n",$21 }')
			# calculating average value
			SUMME=0
			for i in $OUTPUT;
  			  do
    			    SUMME=$(expr $SUMME + $i)
  			  done
			AVG=$(expr ${SUMME} / ${COUNT})
			# checking threshold
			test $AVG $WARN_ARG $CRIT_ARG
			RET_VAL=$?
			# selecting output String (STATISINFORMATION | PERFORMANCEDATA)
			if [ $RET_VAL -eq 0 ]; then
				ECHO_VAL="OK - $AVG time Used by the System|SYS_CPU_TIME=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			elif [ $RET_VAL -eq 1 ]; then
				ECHO_VAL="WARNING - $AVG time Used by the System|SYS_CPU_TIME=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			else 
				ECHO_VAL="CRITICAL - $AVG time Used by the System|SYS_CPU_TIME=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			fi
			;;
		*)
			usage
			exit 2
			;;
	esac

elif [[ $OSSTRING = "Linux" ]];then
	# echo linux

	# Handeling Actions
	case $PARAMETER in
		WAIT_TIME)
			# collecting Data
			RESULT=$(vmstat $INTERVAL $COUNT)
			# removing header
			OUTPUT=$(echo "$RESULT"	| tail -n +3 | awk '{ printf "%d\n",$16 }')
			# calculating average value
			SUMME=0
			for i in $OUTPUT;
  			  do
    			    SUMME=$(expr $SUMME + $i)
  			  done
			AVG=$(expr ${SUMME} / ${COUNT})
			# checking threshold
			test $AVG $WARN_ARG $CRIT_ARG
			RET_VAL=$?
			# selecting output String (STATISINFORMATION | PERFORMANCEDATA)
			if [ $RET_VAL -eq 0 ]; then
				ECHO_VAL="OK - $AVG IO waittime|WAIT_TIME=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			elif [ $RET_VAL -eq 1 ]; then
				ECHO_VAL="WARNING - $AVG IO waittime|WAIT_TIME=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			else 
				ECHO_VAL="CRITICAL - $AVG IO waittime|WAIT_TIME=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			fi
			;;
		PROCESS_QUEUE)
			# collecting Data
			RESULT=$(vmstat $INTERVAL $COUNT)
			# removing header
			OUTPUT=$(echo "$RESULT"	| tail -n +3 | awk '{ printf "%d\n",$1 }')
			# calculating average value
			SUMME=0
			for i in $OUTPUT;
  			  do
    			    SUMME=$(expr $SUMME + $i)
  			  done
			AVG=$(expr ${SUMME} / ${COUNT})
			# checking threshold
			test $AVG $WARN_ARG $CRIT_ARG
			RET_VAL=$?
			# selecting output String (STATISINFORMATION | PERFORMANCEDATA)
			if [ $RET_VAL -eq 0 ]; then
				ECHO_VAL="OK - $AVG processes in queue|PROCESS_QUEUE=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			elif [ $RET_VAL -eq 1 ]; then
				ECHO_VAL="WARNING - $AVG processes in queue|PROCESS_QUEUE=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			else 
				ECHO_VAL="CRITICAL - $AVG processes in queue|PROCESS_QUEUE=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			fi
			;;
		PROCESS_BLOCKED)
			# collecting Data
			RESULT=$(vmstat $INTERVAL $COUNT)
			# removing header
			OUTPUT=$(echo "$RESULT"	| tail -n +3 | awk '{ printf "%d\n",$2 }')
			# calculating average value
			SUMME=0
			for i in $OUTPUT;
  			  do
    			    SUMME=$(expr $SUMME + $i)
  			  done
			AVG=$(expr ${SUMME} / ${COUNT})
			# checking threshold
			test $AVG $WARN_ARG $CRIT_ARG
			RET_VAL=$?
			# selecting output String (STATISINFORMATION | PERFORMANCEDATA)
			if [ $RET_VAL -eq 0 ]; then
				ECHO_VAL="OK - $AVG processes are blocked|PROCESS_BLOCKED=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			elif [ $RET_VAL -eq 1 ]; then
				ECHO_VAL="WARNING - $AVG processes are blocked|PROCESS_BLOCKED=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			else 
				ECHO_VAL="CRITICAL - $AVG processes are blocked|PROCESS_BLOCKED=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			fi
			;;
		SWAP_AVAIL)
			# collecting Data
			AVG=$(vmstat -s |  grep 'free swap' | awk '{ printf "%d\n",$1 }')
			# checking threshold
			test $AVG $WARN_ARG $CRIT_ARG
			RET_VAL=$?
			# Getting total Swap
			AVG_MAX=$(vmstat -s |  grep 'total swap' | awk '{ printf "%d\n",$1 }')
			# selecting output String (STATISINFORMATION | PERFORMANCEDATA)
			if [ $RET_VAL -eq 0 ]; then
				ECHO_VAL="OK - $AVG KB free Swap avial|SWAP_AVAIL="$(expr ${AVG} \* 1024 )"B;"$(expr ${WARN_MIN_VALUE} \* 1024 )";"$(expr ${CRIT_MIN_VALUE} \* 1024 )";0;"$(expr ${AVG_MAX} \* 1024 )
			elif [ $RET_VAL -eq 1 ]; then
				ECHO_VAL="WARNING - $AVG KB free Swap avial|SWAP_AVAIL="$(expr ${AVG} \* 1024 )"B;"$(expr ${WARN_MIN_VALUE} \* 1024 )";"$(expr ${CRIT_MIN_VALUE} \* 1024 )";0;"$(expr ${AVG_MAX} \* 1024 )
			else 
				ECHO_VAL="CRITICAL - $AVG KB free Swap avial|SWAP_AVAIL="$(expr ${AVG} \* 1024 )"B;"$(expr ${WARN_MIN_VALUE} \* 1024 )";"$(expr ${CRIT_MIN_VALUE} \* 1024 )";0;"$(expr ${AVG_MAX} \* 1024 )
			fi
			;;
		PAGE_IN)
			# collecting Data
			AVG=$(vmstat -s |  grep 'pages swapped in' | awk '{ printf "%d\n",$1 }')
			# checking threshold
			test $AVG $WARN_ARG $CRIT_ARG
			RET_VAL=$?
			# selecting output String (STATISINFORMATION | PERFORMANCEDATA)
			if [ $RET_VAL -eq 0 ]; then
				ECHO_VAL="OK - $AVG pages in|PAGE_IN=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			elif [ $RET_VAL -eq 1 ]; then
				ECHO_VAL="WARNING - $AVG pages in|PAGE_IN=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			else 
				ECHO_VAL="CRITICAL - $AVG pages in|PAGE_IN=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			fi
			;;
		PAGE_OUT)
			# collecting Data
			if [ -s /tmp/pageout ]; then
                            AVG1=$(cat /tmp/pageout)
                        else
                            let AVG1=0
                        fi
                        AVG2=$(vmstat -s |  grep 'pages swapped out' | awk '{ printf "%d\n",$1 }' |tee /tmp/pageout)
                        AVG=$((AVG2-AVG1))
			# checking threshold
			test $AVG $WARN_ARG $CRIT_ARG
			RET_VAL=$?
			# selecting output String (STATISINFORMATION | PERFORMANCEDATA)
			if [ $RET_VAL -eq 0 ]; then
				ECHO_VAL="OK - $AVG pages out|PAGE_OUT=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			elif [ $RET_VAL -eq 1 ]; then
				ECHO_VAL="WARNING - $AVG pages out|PAGE_OUT=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			else 
				ECHO_VAL="CRITICAL - $AVG pages out|PAGE_OUT=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			fi
			;;
		SYS_CPU_TIME)
			# collecting Data
			RESULT=$(vmstat $INTERVAL $COUNT)
			# removing header
			OUTPUT=$(echo "$RESULT"	| tail -n +3 | awk '{ printf "%d\n",$14 }')
			# calculating average value
			SUMME=0
			for i in $OUTPUT;
  			  do
    			    SUMME=$(expr $SUMME + $i)
  			  done
			AVG=$(expr ${SUMME} / ${COUNT})
			# checking threshold
			test $AVG $WARN_ARG $CRIT_ARG
			RET_VAL=$?
			ECHO_VAL="'Average Cpu-time used by System'=$AVG"
			# selecting output String (STATISINFORMATION | PERFORMANCEDATA)
			if [ $RET_VAL -eq 0 ]; then
				ECHO_VAL="OK - $AVG time Used by the System|SYS_CPU_TIME=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			elif [ $RET_VAL -eq 1 ]; then
				ECHO_VAL="WARNING - $AVG time Used by the System|SYS_CPU_TIME=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			else 
				ECHO_VAL="CRITICAL - $AVG time Used by the System|SYS_CPU_TIME=$AVG;$WARN_MAX_VALUE;$CRIT_MAX_VALUE;0"
			fi
			;;
		*)
			usage
			exit 2
			;;
	esac
else
	echo OS not supported
fi

echo "$ECHO_VAL"
exit $RET_VAL
