#!/bin/perl
use Carp;
use constant TMPNAGIOS => '/var/log/nagios/downloads';
use constant MONITORINGFILESDIR => '/etc/nagios/conf.d';
use constant MASTERBASELINE => '/etc/nagios/masterBaseline';
use constant SMDIST_TARGETDIR => 'Nagios/targets/';
use constant SMDIST_BASELINEDIR => 'Nagios/baseline/';
use constant OK       => 0;
use constant WARNING  => 1;
use constant CRITICAL => 2;
use constant UNKNOWN  => 3;
use constant TODAY => eval {
   my @date = localtime;
   $date[5] += 1900; $date[4]++;
   sprintf("%04d%02d%02d", $date[5], $date[4], $date[3]);
                           };
use constant LOGGING => eval {
   local $_ = $0;
   s#.*/##;
   s#\..*#.log#;
   my $logfile = "/var/log/nagios/spool/$_";
   "${logfile}";
                            };

use vars qw/$debug $highestLog/;
use strict;

#------------------------------------------------------------------------------------------------------------
#
# Function:    BAwget(target_directory, remote_filename,distribution_server)
# Description: retreives a file from Systems Management repository
#
# Parameters:  target_directory  - the target directory to store the retreived file
#              remote_filename   - the name of the file in the repository
#
#    (taken from BA::Sysman module and modified)
#
#------------------------------------------------------------------------------------------------------------
sub BAwget($$$;$) {
   return BAwget (@_,'smdist') if (@_ == 3);          # Re-call function if only two arguments passed.
   my $func="BAwget";
   if ( @_ != 4 ) { 
	print ("CRITICAL: $func passed incorrect number of arguments - pass directory where file is to be placed and the filename as only arguments\n"); exit 2 }

   loggit('DEBUG', "WGet called with " . join(', ', @_) . " from " . join(':',caller) );
   my $directory=shift;
   my $filename=shift;
   my $acceptableErrors = shift;
   my $dserver=shift;
   my $wget;
   my $syscmd;
   my $url="http://${dserver}:2400/images/${filename}";
   if ( $ENV{'platform'} eq "windows" ) {
      $wget="c:\\jr\\common\\bin\\wget.exe";
      $syscmd="cd /d $directory & $wget -qN $url";
   } else {
      my @possibleDirectories=qw(/usr/bin /opt/local/bin /usr/local/bin);
      foreach my $testdir (@possibleDirectories) {
         if ( -x "${testdir}/wget" ) {
            $wget="${testdir}/wget";
            $syscmd="cd $directory && $wget -N $url 2>&1";
            last;
         }
      }
   }
   if ( ! $wget ) {
      print ("CRITICAL: $func could not find wget program installed - exiting...\n"); exit 2;
   }

   if ( ! -d $directory ) {
      print ("CRITICAL: $func could not find directory $directory - exiting..."); exit 2;
   }

   my @wget=`$syscmd`; my @wget2 = @wget;
   chomp @wget;

   my $error = 1;
   my $http;
   while (my $line = shift @wget2) {
      next unless ( $line =~ /awaiting response/);
      if ($line !~ /awaiting response\.+ (\d+)/) {  # http code can appear here
         local $_ = shift @wget2;
         last unless (m#^\s*HTTP/\S+\s+(\d+)#);   # Expecting HTTP/1.1 nnn msg
      }
      $http = $1;
      $error=0 if ($acceptableErrors =~ /$http/);    # Acceptable http return codes.
      last;
   }

   if ($error) {
      my $baseline=$filename; $baseline =~ s/.*\///; $baseline =~ s/\.cfg//; 
      print ("CRITICAL: $baseline may not be a valid baseline definition. Unable to retrieve ${baseline}.cfg from $dserver\n"); exit 2;
   }

   my $local = $filename; $local =~ s#.*/##;
   my @directory = split('/', $directory);
   pop @directory if ($directory[-1] = '');
   $local = join('/', $directory, $local);
   return ($http, -s $local, -M $local, $local);
}

#------------------------------------------------------------------------------------------------------------
#
# Function:    fatal (message) 
# Description: log and die with appropriate message
#
# Parameters:  message  - the message text
#
#------------------------------------------------------------------------------------------------------------
*fatal = sub {
   my $message='CRITICAL : ' . shift;
   chomp $message;
   #### RAISE_ALERT ($0 failed with $message);
   $Carp::carpLevel = 2;
   if (open (LOG, '>>', LOGGING)) {
      my @date = localtime; my $time = sprintf("%02d%02d%02d", $date[2], $date[1], $date[0]);
      my $msg = "$time : $message\n";
      print LOG $msg;
      close LOG;
   }
   print "$message\n";
   exit CRITICAL;
};

#------------------------------------------------------------------------------------------------------------
#
# Function:    loggit (level, message) 
# Description: output log messages accordingly
#
# Parameters:  level    - the level of the message
#              message  - the message text
#
#------------------------------------------------------------------------------------------------------------
*loggit = sub ($$) {
   my ($level, $message) = (uc(shift), shift);
   my %levels = (
      'DEBUG'    => 0,
      'INFO'     => 0,
      'WARNING'  => 1,
      'ERROR'    => 2
                );

   ($level ne 'DEBUG') || ($debug) || return;
   if (!exists ($levels{$level})) {
      $level .= '?';
      $levels{$level} = 3;
   }
   $highestLog = $levels{$level} if ($levels{$level} > $highestLog);
   chomp $message;
   open (LOG, '>>', LOGGING) or fatal ("Unable to log messages to " . LOGGING . ": $!");
   my @date = localtime; my $time = sprintf("%02d:%02d:%02d", $date[2], $date[1], $date[0]);
   print LOG "${time} : ${level} : ${message}\n";
   close LOG;
};

# point all croak commands, wherever they may be, at the fatal sub.
*Carp::croak = \&fatal;

#------------------------------------------------------------------------------------------------------------
#
# Function:    utsUpdate (filename) 
# Description: Run instantiated by UTS invoking script manually to load / update new master baseline
#
# Parameters:  filename - name of file to be created.
#
#------------------------------------------------------------------------------------------------------------
sub utsUpdate ($) {
   my $file = shift;
   fatal ("Identified file ${file} not found") if (!-e $file);
   fatal ("Identified file ${file} is empty") if (!-s $file);

   my $me = (split(/ /, qx(who -m)))[0];
   open (IN, $file) or fatal ("Cannot open identified file ${file} for read: $!");
   my ($line, $error);
   while (<IN>) {
      chomp;
      ++$line;
      $error .= "$line " unless ( /^[A-Za-z][\w_]+$/ );
   }
   close IN;
   fatal ("Identified file ${file} invalid: Must contain lines consisting of component file names. Lines ${error} do not comply") if (length $error);

   loggit ('INFO', "User ${me} is running utsUpdate to load new baseline configuration ...");
   my $backup = MASTERBASELINE . "." . TODAY;
   if (-e MASTERBASELINE) {
      $error = system("mv " . MASTERBASELINE . " ${backup}");
      fatal ("Unable to backup " . MASTERBASELINE . ". $! $@ $? . . . please investigate") if ($error);
   }

   $error = system("cp ${file} " . MASTERBASELINE);
   fatal ("Unable to copy ${file} to " . MASTERBASELINE . ". $! $@ $? ... Please investigate urgently") if ($error);

   loggit ('INFO', "New baseline file copied into position. Backup is ${backup}");
}

#-----------------------------------------------------------------------------------------------------------------------------------------------
# Main block.
#$debug = 1;
our $utsRun;
our $restartNagiosFlag = 0;

$highestLog = -1;

for (my $i = 0; $i<@ARGV; $i++) {
   local $_ = $ARGV[$i];
   next unless (s/^--//);
   $_=lc;

   $utsRun = $_ if (s/update=//);
   
   $debug = 1 if ($_ eq 'debug');
}

{
   my $message = '<none>';
   $message = join(' ', @ARGV) if (@ARGV);
   loggit('INFO', "starting run. Parms are $message");
}

utsUpdate($utsRun) if (defined ($utsRun));

# (orange bit)
# 1 - confirm presence of master config file
fatal ("Master Baseline config not found or has zero size " . MASTERBASELINE) if (!-s MASTERBASELINE);

# 2 - fetch local host app config file via WGET
system ('rm -rf ' . TMPNAGIOS);
system ('mkdir -p ' . TMPNAGIOS);
my $download = SMDIST_TARGETDIR . `hostname`;
chomp $download;
$download .= '.cfg';
my @wget = BAwget(TMPNAGIOS, $download, '200 404');

# 3 - any problem ?
# also (blue bit) 1 - read from LOCALCONFIG file into @packages.
my @required;
$download = undef;
if ($wget[0] != 404) {    # we found a file.
   if ($wget[1] == 0) {   # file has zero size.
      fatal ("local host file downloaded is of zero size");
   }
   $download = $wget[3];
   if ($wget[2] > 0.01) {  # File is old.
      loggit('INFO', "Using an existing version of the host file");
   }
   open (IN, $download) or fatal ("Cannot open ${download} for reading: $!");
   while (<IN>) {
      push (@required, $_);
      chomp;
      fatal ("Error in ${download} config file: $_") unless ( /^[A-Za-z0-9][\w_]+$/ );
      loggit ('DEBUG', "Application source file entry for $_");
   }
   close IN;
}


# (blue bit)
# 1 - read from config files (MASTERBASELINE)
open (IN, MASTERBASELINE) or fatal ("Unable to open " . MASTERBASELINE . "for read: $!");
while (<IN>) {
   fatal ("Error in " . MASTERBASELINE . " config file: $! TECUTS to investigate urgently") unless ( /^[A-Za-z][\w_]+$/ );
   push (@required, $_);
   loggit ('DEBUG', "Baseline source file entry for $_");
}
close IN;

chomp @required;
map { $_ .= '.cfg' } @required;

my %required;
@required{@required} = ();

# Try and get the catalogued baseline file and record time stamps;
my %catalogued;
{
   my $download = SMDIST_BASELINEDIR . 'baselineCat';
   my @wget = BAwget(TMPNAGIOS, $download, '200 404');
   if ($wget[0] != 404) {
      if (open (CAT, $wget[3])) {
         while(<CAT>) {
            chomp;
            my ($k, $v) = split(/:/,$_);
            $catalogued{$k} = $v if (defined($v));
         }
         close CAT;
      }
   }
}

# Read what we already have :
opendir (DIR, MONITORINGFILESDIR) or fatal ("Could not read current existing configs: $!");
my %localDefs;
while ($_ = readdir DIR) {
   chomp;
   next unless (/\.cfg$/);
   if (exists ($catalogued{$_})) {
      my $fullFile = join('/', MONITORINGFILESDIR, $_);
      my $time = (stat $fullFile)[9];
      my $masterDate = $catalogued{$_};

      $localDefs{$_} = $masterDate > $time ? 0 : $time;
      loggit('DEBUG', "Catalog check for ${fullFile}. MD = ${masterDate}, LF = ${time}, chosen value =" . $localDefs{$_} );
   } else {
      $localDefs{$_} = 0;
      loggit('DEBUG', "$_ no catalog entry found. chosen value = 0" );
   }
   loggit('INFO', "Potential download imminent for $_ as not up to date") if (! $catalogued{$_});
}
%catalogued = ();
my (@uptoDate, %uptoDate);
@uptoDate = grep { $localDefs{$_} > 0 } keys %localDefs;
@uptoDate{@uptoDate} = ();

# Turquoise bit - download what we need
{
   my %list = %required;   # what we should have
   delete @list{ keys %uptoDate };

   for (sort (keys (%list))) {
      my @result = BAwget(TMPNAGIOS, SMDIST_BASELINEDIR . $_, '200');
      if ($result[1] < 5) {
         loggit('ERROR', "$_ (as downloaded) is below minimum size: Ignoring file");
         next;
      }
      my $downloaded = $result[-1];
      my $RC = system("cp $downloaded " . MONITORINGFILESDIR .'/');
      my @loggit = $RC ? ('ERROR', "$_ could not be copied to " . MONITORINGFILESDIR . "/ $! $@ $?") : ('INFO', "$_ updated successfully");
      loggit (@loggit);
      $restartNagiosFlag = 1 unless ($RC);
   }
}

# Green bit - delete what's not wanted
{
   my %list = %localDefs;
   delete @list{ keys %required };

   my $list = keys %list;
   if ($list) {
      my $s = $list == 1 ? '' : 's';
      loggit ('WARNING', "Deletion of ${list} config file$s is required");
      chdir MONITORINGFILESDIR or fatal('Cannot CD to ' . MONITORINGFILESDIR . "/ : $! $@ $? : Urgent: no files have been deleted."); 
      for (sort (keys (%list))) {
         my $RC = unlink;
         my @loggit = $RC ? ('INFO', "$_ deleted successfully") : ('ERROR', "Could not delete $_ : $! $@ $?");
         loggit(@loggit);
         $restartNagiosFlag = 1 if ($RC);
      }
   }
}

# Purple bit - Restart Nagios if needed
if ($restartNagiosFlag) {
   loggit('WARNING', 'NAGIOS config files have been updated, so restarting nagios now');
   print("Restarting Nagios as config files have been updated!\n");
   `sudo /sbin/service nagios restart`;
}

# End of script. 
{
   system('rm -rf ' . TMPNAGIOS);

   my @level = qw/OK OK WARNING CRITICAL/;
   $highestLog = $#level if ($highestLog > $#level);
   my $status = $level[$highestLog];
   my $message = $status . ' - script ends';
   loggit('INFO', $message);
   print "$message\n";

   my $exit =
      $status eq 'OK' ? OK
    : $status eq 'WARNING' ? WARNING 
    : $status eq 'CRITICAL' ? CRITICAL
    : UNKNOWN
   ;

   exit $exit;
}
