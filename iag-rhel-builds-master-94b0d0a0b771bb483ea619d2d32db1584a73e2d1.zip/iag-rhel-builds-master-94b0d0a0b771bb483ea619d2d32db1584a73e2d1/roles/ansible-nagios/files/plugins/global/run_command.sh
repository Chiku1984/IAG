#!/bin/bash

# USAGE: run_command.sh [-Vh] [-p parameter [[-w threshold| -c threshold]]]     #






################################################################################
#      RUN_COMMAND PLUGIN
################################################################################
# USAGE: run_command.sh [-Vh] [-p parameter [[-w threshold| -c threshold]]]    	#
#                                                                              	#
#     Parameters:                                                              	#
#	                                                                       	#
#	 COMMAND							       	#
#	     Command to run by nagios, should be executable by nagios or sudo  	#
#	     rules exits                                                       	#
#	                                                                       	#
#	Options:                                                               	#
#                                                                              	#
#	 -h                                                                    	#
#	     Displays this help dialog                                         	#
#	                                                                       	#
#	 -V                                                                    	#
#	     Displays Version and Credits                                      	#
#                                                                              	#
#	 -p  set command to be executed by Nagios			       	#
#                                                                              	#
#	 -w                                                                    	#
#	     sets the warning output . 					       	#
#                                                                              	#
#	 -c                                                                    	#
#	     sets the critical  output					       	#
#                                                                              	#
#	Warn/Crit Formate note:                                                	#
#	1.	starts with string= or numeric=				        #
#	2.	if string operands are: ~=matches !~=doesnot match	        #
#	3.	if numeric operands are: eq, gt, ge, ne, lt, le 	        #
#		(inclusive of endpoints)                                        #
#                                                                               #
#	Examples:                                                               #
#	-w "string=~patrol"	       					        #
#	-c "string=~SUCCESSFUL;!~ERROR" 				       	#
#	-c "numeric==0" 							#
#                                                                              	#
#################################################################################

version ()
{
	sed -e 's/^    //'<<EndVersion
	Nagios VMIO-Plugin
	Version 1.0
	Author: Matthias Clemen (matthias-clemen@gmx.de)
	Release date:
	Last updated:
	Licence: GPL V.3 Copyright (C) 2008  
		ElectronicPartner Handel GmbH & 
		Matthias Clemen 



EndVersion
	exit 1
}
	
help()
{
	sed -e 's/^    //'<<EndHelp
	Usage: 
	  run_command.sh [-Vh] [-p parameter [-w threshold] [-c threshold]]
	
	
	Options:

	 -h
	     Displays this help dialog
	 
	 -V
	     Displays Version
	     
	 -p
	     sets which command to be exectued by Nagios

	 -w
	     sets the warning thredhold. 

	 -c
	     sets the critical thredhold. 


EndHelp
	exit 1
}

usage()
{
	sed -e 's/^    //'<<EndUsage
	Usage: 
	 run_command.sh [-Vh] [-p command [-w output ] [-c output]]
	 run_command.sh -p 'cksum /usr/src/RPMS/oasis-cluster-0.1-1.el5.noarch.rpm' -c 'string=~3216432124 6004'
	 run_command.sh -p 'cksum /usr/src/RPMS/oasis-cluster-0.1-1.el5.noarch.rpm' -w 'string=~3216432124 6004'



EndUsage
}


# min 2 parameters
if [[ $# -lt 2 ]];then 
	usage
	exit 3
fi

#defaults
WARN_ARG=""
CRIT_ARG=""
COMMAND=NONE #Splitting Parameter
RET_VAL=0
ECHO_VAL= 
while getopts "Vvhp:w:c:" Option 
do
	case $Option in
		h)
			help
			;;
		V)
			version
			;;
		w)
			WARN_ARG=$OPTARG
			;;
		c)
			CRIT_ARG=$OPTARG
			;;
		p)
			COMMAND=$OPTARG
			;;
		?)
			usage
			exit 2
			;;
	esac
done
#checking warning or critical output supplied
if [[ -z "$WARN_ARG" ]] && [[ -z "$CRIT_ARG" ]]; then
    echo "Missing Warning/Critical Threshold"
    RET_VAL=3
    #exit 3
fi

#if [[ -n $WARN_ARG ]] && [[ $(echo "$WARN_ARG" | awk '{if ($0~/^string=[~|!~].*$/ || $0~/^numeric:[eq|ne|gt|ge|lt|le]:[0-9]*$/) printf "%d",1; else printf "%d",0 }') -eq 0 ]];then
if [[ -n $WARN_ARG ]] && [[ $(echo "$WARN_ARG" | awk '{if ($0~/^string=[~|!~].*$/) printf "%d",1; else printf "%d",0 }') -eq 0 ]];then
    ECHO_VAL="Incorrect warning output supplied: output=$WARN_ARG"
else 
    CHECK_WARN=1
    if [[ $(echo "$WARN_ARG" |grep -c "string=~") -eq 1 ]];then
    	WARN_OPERAND="MATCH"
        WARN_TEXT=$(echo "$WARN_ARG" |sed 's/string=~//')
    elif [[ $(echo "$WARN_ARG" |grep -c "string:!~") -eq 1 ]];then
    	WARN_OPERAND="NOT_MATCH"
        WARN_TEXT=$(echo "$WARN_ARG" |sed 's/string=!~//')
#    elif [[ $(echo "$WARN_ARG" |grep -c "numeric:eq:") -eq 1 ]];then
#    	WARN_OPERAND="EQUAL"
#        WARN_TEXT=$(echo "$WARN_ARG" |sed 's/numeric:eq://')
#    elif [[ $(echo "$WARN_ARG" |grep -c "numeric:gt:") -eq 1 ]];then
#    	WARN_OPERAND="GREATER"
#        WARN_TEXT=$(echo "$WARN_ARG" |sed 's/numeric:gt://')
#    elif [[ $(echo "$WARN_ARG" |grep -c "numeric:lt:") -eq 1 ]];then
#    	WARN_OPERAND="LESS"
#        WARN_TEXT=$(echo "$WARN_ARG" |sed 's/numeric:lt://')
    fi
    #echo "WARN_OPERAND:$WARN_OPERAND WARN_TEXT:$WARN_TEXT"
fi

#if [[ ! -n "$CRIT_ARG" ]] && [[ $(echo "$CRIT_ARG" | awk '{if ($0~/^string=[~|!~].*$/ || $0~/^numeric:[eq|ne|gt|ge|lt|le]:[0-9]*$/) printf "%d",1; else printf "%d",0 }') -eq 0 ]];then

if [[ -n "$CRIT_ARG" &&  $(echo "$CRIT_ARG" | awk '{if ($0~/^string=[~|!~].*$/) printf "%d",1; else printf "%d",0 }') -eq 0 ]];then
    ECHO_VAL="Incorrect critical output supplied: output=$CRIT_ARG"
    RET_VAL=3
    #usage
    #exit 3
else 
    CHECK_CRIT=1
    if [[ $(echo "$CRIT_ARG" |grep -c "string=~") -eq 1 ]];then
    	CRIT_OPERAND=MATCH
        CRIT_TEXT=$(echo "$CRIT_ARG" |sed 's/string=~//')
    elif [[ $(echo "$CRIT_ARG" |grep -c "string=!~") -eq 1 ]];then
    	CRIT_OPERAND=NON_MATCH
        CRIT_TEXT=$(echo "$CRIT_ARG" |sed 's/string=!~//')
#    elif [[ $(echo "$CRIT_ARG" |grep -c "numeric:=") -eq 1 ]];then
#    	CRIT_OPERAND=EQUAL
#        CRIT_TEXT=$(echo "$CRIT_ARG" |sed 's/numeric:=//')
#    elif [[ $(echo "$CRIT_ARG" |grep -c "numeric:>") -eq 1 ]];then
#    	CRIT_OPERAND=GREATER
#        CRIT_TEXT=$(echo "$CRIT_ARG" |sed 's/numeric:>//')
#    elif [[ $(echo "$CRIT_ARG" |grep -c "numeric:<") -eq 1 ]];then
#    	CRIT_OPERAND=LESS
#        CRIT_TEXT=$(echo "$CRIT_ARG" |sed 's/numeric:<//')
    fi
    #echo "CRIT_OPERAND:$CRIT_OPERAND CRIT_TEXT:$CRIT_TEXT"
fi

#echo "COMMAND:$COMMAND"
#echo "WARN_ARG:$WARN_ARG WARN_OPERAND:$WARN_OPERAND WARN_TEXT:$WARN_TEXT"
#echo "CRIT_ARG:$CRIT_ARG CRIT_OPERAND:$CRIT_OPERAND CRIT_TEXT:$CRIT_TEXT"
#
if [[ $RET_VAL -ne 3 ]]; then
$COMMAND 2>&1 >/tmp/run_command.sh.$$.out 
RC=$?
fi
if [[ $RC -ne 0 ]]; then
    ECHO_VAL="$COMMAND failed to run return code:$RC"
    if [[ $CHECK_CRIT -eq 1 ]]; then
	RET_VAL=2
    elif [[ $CHECK_WARN -eq 1 ]]; then
	RET_VAL=1
    fi 
elif [[ $CHECK_CRIT -eq 1 ]]; then
    # checking output
    case $CRIT_OPERAND in
	MATCH)
	    if [[ $(grep -c "$CRIT_TEXT" /tmp/run_command.sh.$$.out) -gt 0 ]]; then
		RET_VAL=0
		OUTPUT=$(grep "$CRIT_TEXT" /tmp/run_command.sh.$$.out)
		ECHO_VAL="OK - $OUTPUT detected"
	    else 
		RET_VAL=2
		ECHO_VAL="CRITICAL - $CRIT_TEXT not detected"
	    fi
	    ;;
	NON_MATCH)
	    if [[ $(grep -c "$CRIT_TEXT" /tmp/run_command.sh.$$.out) -eq 0 ]]; then
		RET_VAL=0
		ECHO_VAL="OK - $CRIT_TEXT not detected"
	    else 
		RET_VAL=2
		OUTPUT=$(grep "$CRIT_TEXT" /tmp/run_command.sh.$$.out)
		ECHO_VAL="CRITICAL - $OUTPUT detected"
	    fi
	    ;;
    esac
    # do we need to check for warning too
    if [[ $RET_VAL -ne 2 && $CHECK_WARN -eq 1 ]]; then 
        case $WARN_OPERAND in
	    MATCH)
	        if [[ $(grep -c "$WARN_TEXT" /tmp/run_command.sh.$$.out) -gt 0 ]]; then
	    	   RET_VAL=0
	    	   OUTPUT=$(grep "$WARN_TEXT" /tmp/run_command.sh.$$.out)
	    	   ECHO_VAL="OK - $OUTPUT detected"
	        else 
	    	   RET_VAL=1
	    	   ECHO_VAL="WARNING - $WARN_TEXT not detected"
	        fi
	        ;;
	    NON_MATCH)
	        if [[ $(grep -c "$WARN_TEXT" /tmp/run_command.sh.$$.out) -eq 0 ]]; then
	    	   RET_VAL=0
	    	   ECHO_VAL="OK - $WARN_TEXT not detected"
	        else 
	    	   RET_VAL=1
	    	   OUTPUT=$(grep "$WARN_TEXT" /tmp/run_command.sh.$$.out)
	    	   ECHO_VAL="WARNING - $OUTPUT detected"
	        fi
	        ;;
        esac
    fi
elif [[ $CHECK_WARN -eq 1 ]]; then
    case $WARN_OPERAND in
        MATCH)
	    if [[ $(grep -c "$WARN_TEXT" /tmp/run_command.sh.$$.out) -gt 0 ]]; then
	    	RET_VAL=0
	    	OUTPUT=$(grep "$WARN_TEXT" /tmp/run_command.sh.$$.out)
	    	ECHO_VAL="OK - $OUTPUT detected"
	    else 
	    	RET_VAL=1
	    	ECHO_VAL="WARNING - $WARN_TEXT not detected"
	    fi
	    ;;
	NON_MATCH)
	    if [[ $(grep -c "$WARN_TEXT" /tmp/run_command.sh.$$.out) -eq 0 ]]; then
	    	RET_VAL=0
	    	ECHO_VAL="OK - $WARN_TEXT not detected"
	    else 
	    	RET_VAL=1
	    	OUTPUT=$(grep "$WARN_TEXT" /tmp/run_command.sh.$$.out)
	    	ECHO_VAL="WARNING - $OUTPUT detected"
	    fi
	    ;;
    esac
fi
rm -f /tmp/run_command.sh.$$.out
echo "$ECHO_VAL"
exit $RET_VAL
