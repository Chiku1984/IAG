This is just a placeholder so that git doesn't ignore this folder
